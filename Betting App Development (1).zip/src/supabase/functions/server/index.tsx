import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Generate verification code (e.g., "07rx")
function generateVerificationCode(): string {
  const num = Math.floor(Math.random() * 100).toString().padStart(2, '0');
  const letters = String.fromCharCode(97 + Math.floor(Math.random() * 26)) + 
                  String.fromCharCode(97 + Math.floor(Math.random() * 26));
  return num + letters;
}

// Signup route
app.post('/make-server-c7fe758c/signup', async (c) => {
  try {
    const { email, phone, countryCode, type } = await c.req.json();
    
    // Generate verification code
    const verificationCode = generateVerificationCode();
    
    // Store pending signup with verification code
    const pendingKey = `pending_${type}_${email || phone}`;
    await kv.set(pendingKey, {
      email,
      phone,
      countryCode,
      verificationCode,
      type,
      timestamp: Date.now()
    });
    
    console.log(`Signup initiated for ${email || phone}, verification code: ${verificationCode}`);
    
    return c.json({ 
      success: true, 
      verificationCode, // In production, this would be sent via SMS/Email
      message: 'Verification code generated' 
    });
  } catch (error) {
    console.log(`Signup error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Verify code route
app.post('/make-server-c7fe758c/verify', async (c) => {
  try {
    const { email, phone, type, code } = await c.req.json();
    
    const pendingKey = `pending_${type}_${email || phone}`;
    const pending = await kv.get(pendingKey);
    
    if (!pending) {
      return c.json({ success: false, error: 'No pending signup found' }, 400);
    }
    
    if (pending.verificationCode !== code) {
      return c.json({ success: false, error: 'Invalid verification code' }, 400);
    }
    
    // Delete pending signup
    await kv.del(pendingKey);
    
    return c.json({ 
      success: true, 
      message: 'Verification successful',
      data: pending
    });
  } catch (error) {
    console.log(`Verification error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Complete profile and create user
app.post('/make-server-c7fe758c/complete-profile', async (c) => {
  try {
    const { email, phone, username, avatar, password } = await c.req.json();
    
    // Create user with Supabase Auth
    let authData;
    if (email) {
      authData = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { username, avatar }
      });
    } else {
      // For phone-only signup, use email format
      const fakeEmail = `${phone}@bimbett.app`;
      authData = await supabase.auth.admin.createUser({
        email: fakeEmail,
        password,
        email_confirm: true,
        user_metadata: { username, avatar, phone }
      });
    }
    
    if (authData.error) {
      return c.json({ success: false, error: authData.error.message }, 400);
    }
    
    const userId = authData.data.user!.id;
    
    // Initialize user data with 1000 FRW signup bonus
    await kv.set(`user_${userId}`, {
      userId,
      email,
      phone,
      username,
      avatar,
      wallet: 1000, // Signup bonus
      totalDeposited: 0,
      totalWithdrawn: 0,
      gamesPlayed: 0,
      createdAt: Date.now()
    });
    
    // Initialize bonuses
    await kv.set(`bonuses_${userId}`, {
      signupBonus: 1000,
      instagramBonus: 0,
      videoLikesBonus: 0
    });
    
    console.log(`User profile created for ${username} with 1000 FRW bonus`);
    
    return c.json({ success: true, userId });
  } catch (error) {
    console.log(`Profile completion error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Login route
app.post('/make-server-c7fe758c/login', async (c) => {
  try {
    const { email, phone, password } = await c.req.json();
    
    let loginEmail = email;
    if (!email && phone) {
      loginEmail = `${phone}@bimbett.app`;
    }
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email: loginEmail,
      password
    });
    
    if (error) {
      return c.json({ success: false, error: error.message }, 400);
    }
    
    return c.json({ 
      success: true, 
      accessToken: data.session.access_token,
      userId: data.user.id
    });
  } catch (error) {
    console.log(`Login error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get user profile
app.get('/make-server-c7fe758c/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const userData = await kv.get(`user_${user.id}`);
    const bonuses = await kv.get(`bonuses_${user.id}`);
    
    return c.json({ 
      success: true, 
      user: userData,
      bonuses
    });
  } catch (error) {
    console.log(`Get profile error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Deposit money
app.post('/make-server-c7fe758c/deposit', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const { amount, method } = await c.req.json(); // method: MTN or AIRTEL
    
    // Calculate tax (12%)
    const tax = amount * 0.12;
    const netAmount = amount - tax;
    
    const userData = await kv.get(`user_${user.id}`);
    userData.wallet += netAmount;
    userData.totalDeposited += amount;
    
    await kv.set(`user_${user.id}`, userData);
    
    // Log transaction
    const transactionId = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await kv.set(transactionId, {
      userId: user.id,
      type: 'deposit',
      amount,
      tax,
      netAmount,
      method,
      timestamp: Date.now()
    });
    
    console.log(`Deposit: ${amount} FRW (${method}), tax: ${tax} FRW, net: ${netAmount} FRW for user ${user.id}`);
    
    return c.json({ 
      success: true, 
      newBalance: userData.wallet,
      tax,
      netAmount
    });
  } catch (error) {
    console.log(`Deposit error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Withdraw money
app.post('/make-server-c7fe758c/withdraw', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const { amount, method, phone } = await c.req.json();
    
    const userData = await kv.get(`user_${user.id}`);
    
    // Check minimum withdrawal
    if (userData.wallet < 3000) {
      return c.json({ success: false, error: 'Minimum withdrawal is 3000 FRW' }, 400);
    }
    
    if (userData.wallet < amount) {
      return c.json({ success: false, error: 'Insufficient balance' }, 400);
    }
    
    userData.wallet -= amount;
    userData.totalWithdrawn += amount;
    
    await kv.set(`user_${user.id}`, userData);
    
    // Log transaction
    const transactionId = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await kv.set(transactionId, {
      userId: user.id,
      type: 'withdraw',
      amount,
      method,
      phone,
      timestamp: Date.now()
    });
    
    console.log(`Withdrawal: ${amount} FRW to ${phone} (${method}) for user ${user.id}`);
    
    return c.json({ 
      success: true, 
      newBalance: userData.wallet
    });
  } catch (error) {
    console.log(`Withdrawal error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Place bet
app.post('/make-server-c7fe758c/place-bet', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const { gameType, betAmount, gameData } = await c.req.json();
    
    const userData = await kv.get(`user_${user.id}`);
    
    if (userData.wallet < betAmount) {
      return c.json({ success: false, error: 'Insufficient balance' }, 400);
    }
    
    userData.wallet -= betAmount;
    userData.gamesPlayed += 1;
    await kv.set(`user_${user.id}`, userData);
    
    const betId = `bet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return c.json({ 
      success: true, 
      betId,
      newBalance: userData.wallet
    });
  } catch (error) {
    console.log(`Place bet error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Win bet
app.post('/make-server-c7fe758c/win-bet', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const { betId, winAmount, gameType, gameData } = await c.req.json();
    
    const userData = await kv.get(`user_${user.id}`);
    userData.wallet += winAmount;
    await kv.set(`user_${user.id}`, userData);
    
    // Save to history
    const historyId = `history_${user.id}_${Date.now()}`;
    await kv.set(historyId, {
      userId: user.id,
      betId,
      gameType,
      winAmount,
      gameData,
      timestamp: Date.now()
    });
    
    console.log(`Win: ${winAmount} FRW for user ${user.id} in ${gameType}`);
    
    return c.json({ 
      success: true, 
      newBalance: userData.wallet
    });
  } catch (error) {
    console.log(`Win bet error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get game history
app.get('/make-server-c7fe758c/history', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const historyKeys = await kv.getByPrefix(`history_${user.id}_`);
    const history = historyKeys.sort((a, b) => b.timestamp - a.timestamp).slice(0, 50);
    
    return c.json({ success: true, history });
  } catch (error) {
    console.log(`Get history error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Add Instagram bonus
app.post('/make-server-c7fe758c/instagram-bonus', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const bonuses = await kv.get(`bonuses_${user.id}`);
    
    if (bonuses.instagramBonus > 0) {
      return c.json({ success: false, error: 'Instagram bonus already claimed' }, 400);
    }
    
    bonuses.instagramBonus = 2000; // 1000 per account
    await kv.set(`bonuses_${user.id}`, bonuses);
    
    const userData = await kv.get(`user_${user.id}`);
    userData.wallet += 2000;
    await kv.set(`user_${user.id}`, userData);
    
    return c.json({ success: true, newBalance: userData.wallet });
  } catch (error) {
    console.log(`Instagram bonus error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Add video like bonus
app.post('/make-server-c7fe758c/video-like', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ success: false, error: 'Unauthorized' }, 401);
    }
    
    const bonuses = await kv.get(`bonuses_${user.id}`);
    bonuses.videoLikesBonus += 50;
    await kv.set(`bonuses_${user.id}`, bonuses);
    
    const userData = await kv.get(`user_${user.id}`);
    userData.wallet += 50;
    await kv.set(`user_${user.id}`, userData);
    
    return c.json({ success: true, newBalance: userData.wallet });
  } catch (error) {
    console.log(`Video like bonus error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get sports matches
app.get('/make-server-c7fe758c/sports-matches', async (c) => {
  try {
    // Mock sports matches data
    const matches = {
      football: [
        { id: 'fb1', home: 'Arsenal', away: 'Chelsea', homeOdds: 2.3, awayOdds: 1.8, drawOdds: 3.2, time: '2025-11-01 15:00' },
        { id: 'fb2', home: 'Barcelona', away: 'Real Madrid', homeOdds: 1.9, awayOdds: 2.1, drawOdds: 3.5, time: '2025-11-01 18:00' },
        { id: 'fb3', home: 'Liverpool', away: 'Man City', homeOdds: 2.5, awayOdds: 1.7, drawOdds: 3.0, time: '2025-11-02 20:00' }
      ],
      basketball: [
        { id: 'bb1', home: 'Lakers', away: 'Warriors', homeOdds: 1.85, awayOdds: 1.95, time: '2025-11-01 19:30' },
        { id: 'bb2', home: 'Celtics', away: 'Heat', homeOdds: 2.1, awayOdds: 1.75, time: '2025-11-02 21:00' }
      ],
      volleyball: [
        { id: 'vb1', home: 'Brazil', away: 'USA', homeOdds: 2.2, awayOdds: 1.65, time: '2025-11-01 16:00' },
        { id: 'vb2', home: 'Poland', away: 'Italy', homeOdds: 1.9, awayOdds: 1.9, time: '2025-11-02 17:00' }
      ]
    };
    
    return c.json({ success: true, matches });
  } catch (error) {
    console.log(`Get sports matches error: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

Deno.serve(app.fetch);
