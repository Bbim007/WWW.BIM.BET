import { useState, useEffect } from 'react';
import { AuthPage } from './components/AuthPage';
import { VerificationPage } from './components/VerificationPage';
import { RobotVerificationPage } from './components/RobotVerificationPage';
import { ProfileSetupPage } from './components/ProfileSetupPage';
import { MainDashboard } from './components/MainDashboard';
import { Toaster } from './components/ui/sonner';
import './styles/globals.css';
import { projectId, publicAnonKey } from './utils/supabase/info';

type AppState = 'auth' | 'verification' | 'robot' | 'profile' | 'main';

export default function App() {
  const [state, setState] = useState<AppState>('auth');
  const [pendingAuth, setPendingAuth] = useState<any>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState('');

  // Load Google Fonts and set favicon
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    // Set page title and favicon
    document.title = 'B!MBETT - Premium Betting';
    
    // Create a data URL for the "B" favicon
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Background
      ctx.fillStyle = '#0a0015';
      ctx.fillRect(0, 0, 64, 64);
      
      // Gradient for B
      const gradient = ctx.createLinearGradient(0, 0, 64, 64);
      gradient.addColorStop(0, '#fbbf24');
      gradient.addColorStop(0.5, '#f59e0b');
      gradient.addColorStop(1, '#d97706');
      
      ctx.fillStyle = gradient;
      ctx.font = 'bold 48px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('B', 32, 32);
    }
    
    const favicon = document.createElement('link');
    favicon.rel = 'icon';
    favicon.href = canvas.toDataURL();
    document.head.appendChild(favicon);
  }, []);

  const handleSignup = async (data: any) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/signup`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        }
      );

      const result = await response.json();
      
      if (result.success) {
        setPendingAuth(data);
        setVerificationCode(result.verificationCode);
        setState('verification');
      } else {
        alert('Signup failed: ' + (result.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Signup error:', error);
      alert('Signup failed. Please try again.');
    }
  };

  const handleLogin = async (data: any) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/login`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        }
      );

      const result = await response.json();
      
      if (result.success) {
        setAccessToken(result.accessToken);
        await loadUserProfile(result.accessToken);
        setState('main');
      } else {
        alert('Login failed: ' + (result.error || 'Invalid credentials'));
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('Login failed. Please try again.');
    }
  };

  const handleVerification = async (code: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/verify`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: pendingAuth.email,
            phone: pendingAuth.phone,
            type: pendingAuth.type,
            code
          })
        }
      );

      const result = await response.json();
      
      if (result.success) {
        setState('robot');
      } else {
        alert('Verification failed: ' + (result.error || 'Invalid code'));
      }
    } catch (error) {
      console.error('Verification error:', error);
      alert('Verification failed. Please try again.');
    }
  };

  const handleRobotVerification = () => {
    setState('profile');
  };

  const handleProfileComplete = async (username: string, avatar: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/complete-profile`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: pendingAuth.email,
            phone: pendingAuth.phone,
            username,
            avatar,
            password: pendingAuth.password
          })
        }
      );

      const result = await response.json();
      
      if (result.success) {
        // Auto login after profile completion
        const loginData = pendingAuth.email 
          ? { email: pendingAuth.email, password: pendingAuth.password }
          : { phone: pendingAuth.phone, password: pendingAuth.password };
        
        await handleLogin(loginData);
      } else {
        alert('Profile creation failed: ' + (result.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Profile completion error:', error);
      alert('Profile creation failed. Please try again.');
    }
  };

  const loadUserProfile = async (token: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/profile`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      const result = await response.json();
      
      if (result.success) {
        setUser(result.user);
      }
    } catch (error) {
      console.error('Load profile error:', error);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setAccessToken('');
    setPendingAuth(null);
    setState('auth');
  };

  const handleUpdateBalance = (newBalance: number) => {
    setUser((prev: any) => ({
      ...prev,
      wallet: newBalance
    }));
  };

  return (
    <div className="min-h-screen">
      <Toaster position="top-center" richColors />
      
      {state === 'auth' && (
        <AuthPage onSignup={handleSignup} onLogin={handleLogin} />
      )}

      {state === 'verification' && (
        <VerificationPage
          identifier={pendingAuth.email || pendingAuth.phone}
          verificationCode={verificationCode}
          onVerify={handleVerification}
        />
      )}

      {state === 'robot' && (
        <RobotVerificationPage onVerify={handleRobotVerification} />
      )}

      {state === 'profile' && (
        <ProfileSetupPage onComplete={handleProfileComplete} />
      )}

      {state === 'main' && user && (
        <MainDashboard
          user={user}
          accessToken={accessToken}
          onLogout={handleLogout}
          onUpdateBalance={handleUpdateBalance}
        />
      )}
    </div>
  );
}
