import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { History, TrendingUp, TrendingDown } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface GameHistoryProps {
  accessToken: string;
}

export function GameHistory({ accessToken }: GameHistoryProps) {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/history`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (data.success) {
        setHistory(data.history);
      }
    } catch (error) {
      console.error('Fetch history error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getGameIcon = (gameType: string) => {
    const icons: Record<string, string> = {
      'spin': '🎡',
      'crash': '✈️',
      'slots': '🎰',
      'blackjack': '🃏',
      'rolling': '⚽',
      'sports': '🏆',
      'unique_car': '🏎️',
      'unique_airplane': '✈️',
      'unique_horse': '🐎'
    };
    return icons[gameType] || '🎮';
  };

  const getGameName = (gameType: string) => {
    const names: Record<string, string> = {
      'spin': 'Spin Wheel',
      'crash': 'Aviator Crash',
      'slots': 'Slots',
      'blackjack': 'Blackjack',
      'rolling': 'Rolling Ball',
      'sports': 'Sports Betting',
      'unique_car': 'Car Racing',
      'unique_airplane': 'Airplane',
      'unique_horse': 'Horse Racing'
    };
    return names[gameType] || gameType;
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full mx-auto"></div>
        <p className="text-gray-400 mt-4">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl neon-text mb-2">Game History</h2>
        <p className="text-gray-400">Your recent gaming activity</p>
      </div>

      {history.length === 0 ? (
        <Card className="bg-black/70 border-purple-500/30 p-12 text-center">
          <History className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">No game history yet</p>
          <p className="text-gray-500 text-sm mt-2">Start playing to see your history here!</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {history.map((item, index) => (
            <Card 
              key={index}
              className="bg-black/70 border-purple-500/30 hover:border-purple-500 transition-all p-4"
            >
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="text-3xl">{getGameIcon(item.gameType)}</div>
                  <div>
                    <h4 className="text-lg">{getGameName(item.gameType)}</h4>
                    <p className="text-xs text-gray-400">{formatDate(item.timestamp)}</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {item.gameData?.multiplier && (
                    <Badge className="bg-purple-500/20 border-purple-500">
                      {item.gameData.multiplier.toFixed(2)}x
                    </Badge>
                  )}

                  <div className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 ${
                    item.winAmount > 0 
                      ? 'bg-green-500/20 border-green-500' 
                      : 'bg-gray-500/20 border-gray-500'
                  }`}>
                    {item.winAmount > 0 ? (
                      <>
                        <TrendingUp className="w-5 h-5 text-green-400" />
                        <div className="text-right">
                          <div className="text-sm text-gray-400">Won</div>
                          <div className="text-lg text-green-400">{item.winAmount.toFixed(0)} FRW</div>
                        </div>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-5 h-5 text-gray-400" />
                        <div className="text-right">
                          <div className="text-sm text-gray-400">Lost</div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Additional game details */}
              {item.gameData && (
                <div className="mt-3 pt-3 border-t border-purple-500/20 text-xs text-gray-400">
                  {item.gameType === 'sports' && item.gameData.match && (
                    <p>
                      {item.gameData.match.home} vs {item.gameData.match.away} - 
                      Bet on: {item.gameData.outcome} ({item.gameData.odds}x)
                    </p>
                  )}
                  {item.gameType === 'slots' && item.gameData.slots && (
                    <p>
                      Slots: {item.gameData.slots.join(' ')}
                    </p>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
