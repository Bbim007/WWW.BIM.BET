import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Wallet, 
  Gamepad2, 
  Trophy, 
  History, 
  LogOut, 
  Instagram,
  MessageCircle,
  Plus,
  Minus,
  Star
} from 'lucide-react';
import { CasinoGames } from './CasinoGames';
import { SportsBooking } from './SportsBooking';
import { UniqueGames } from './UniqueGames';
import { PaymentModal } from './PaymentModal';
import { GameHistory } from './GameHistory';
import { AdvertisementPanel } from './AdvertisementPanel';
import { AnimatedLogo } from './AnimatedLogo';
import { IBIMChatBot } from './iBIMChatBot';
import { projectId } from '../utils/supabase/info';

interface MainDashboardProps {
  user: any;
  accessToken: string;
  onLogout: () => void;
  onUpdateBalance: (newBalance: number) => void;
}

export function MainDashboard({ user, accessToken, onLogout, onUpdateBalance }: MainDashboardProps) {
  const [activeTab, setActiveTab] = useState('home');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentType, setPaymentType] = useState<'deposit' | 'withdraw'>('deposit');
  const [instagramBonusClaimed, setInstagramBonusClaimed] = useState(false);
  const [instagramBonus1, setInstagramBonus1] = useState(false);
  const [instagramBonus2, setInstagramBonus2] = useState(false);

  const avatarEmojis: Record<string, string> = {
    male: '👨',
    female: '👩',
    oldmale: '👴',
    oldfemale: '👵'
  };

  const handleClaimInstagramBonus = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/instagram-bonus`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      if (data.success) {
        onUpdateBalance(data.newBalance);
        setInstagramBonusClaimed(true);
      }
    } catch (error) {
      console.error('Instagram bonus claim error:', error);
    }
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/250739980847', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0a0015]">
      {/* Neon border effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 neon-glow"></div>
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 neon-glow"></div>
        <div className="absolute top-0 bottom-0 left-0 w-1 bg-gradient-to-b from-pink-500 via-purple-500 to-cyan-500 neon-glow"></div>
        <div className="absolute top-0 bottom-0 right-0 w-1 bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500 neon-glow"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-purple-500/30 bg-black/50 backdrop-blur-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <AnimatedLogo size="small" />
              <Badge className="bg-yellow-500/20 border-yellow-500 text-yellow-400">
                +10 Years
              </Badge>
            </div>

            {/* User Info */}
            <div className="flex items-center gap-4 flex-wrap">
              {/* Wallet */}
              <Card className="bg-black/70 border-green-500 px-4 py-2 flex items-center gap-2">
                <Wallet className="w-5 h-5 text-green-400" />
                <div>
                  <div className="text-xs text-gray-400">Wallet</div>
                  <div className="text-lg text-green-400">{user.wallet.toFixed(0)} FRW</div>
                </div>
              </Card>

              {/* Deposit/Withdraw Buttons */}
              <Button
                onClick={() => {
                  setPaymentType('deposit');
                  setShowPaymentModal(true);
                }}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-1" />
                Deposit
              </Button>

              <Button
                onClick={() => {
                  setPaymentType('withdraw');
                  setShowPaymentModal(true);
                }}
                variant="outline"
                className="border-cyan-500 text-cyan-400"
                disabled={user.wallet < 3000}
              >
                <Minus className="w-4 h-4 mr-1" />
                Withdraw
              </Button>

              {/* Profile */}
              <div className="flex items-center gap-2 px-3 py-2 bg-purple-500/20 border border-purple-500 rounded-lg">
                {user.avatar?.startsWith('data:') ? (
                  <img src={user.avatar} alt="Profile" className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <span className="text-2xl">{avatarEmojis[user.avatar] || '👤'}</span>
                )}
                <span className="text-sm text-purple-300">{user.username}</span>
              </div>

              {/* Logout */}
              <Button
                onClick={onLogout}
                variant="ghost"
                size="icon"
                className="text-red-400 hover:text-red-300"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Social Bonuses */}
          <div className="mt-4 flex gap-3 flex-wrap">
            {!instagramBonusClaimed && (
              <Button
                onClick={handleClaimInstagramBonus}
                variant="outline"
                size="sm"
                className="border-pink-500 text-pink-400 hover:bg-pink-500/20"
              >
                <Instagram className="w-4 h-4 mr-2" />
                Follow @___bim_is_ & @___bim_was_ (+2000 FRW)
              </Button>
            )}
            
            <Button
              onClick={openWhatsApp}
              variant="outline"
              size="sm"
              className="border-green-500 text-green-400 hover:bg-green-500/20"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              WhatsApp: 0739980847
            </Button>

            {user.wallet < 3000 && (
              <Badge variant="outline" className="border-yellow-500 text-yellow-400">
                Minimum 3000 FRW to withdraw
              </Badge>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-black/50 backdrop-blur-lg border border-purple-500/30 p-1">
            <TabsTrigger 
              value="home" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-500 data-[state=active]:to-pink-500"
            >
              <Star className="w-4 h-4 mr-2" />
              Home
            </TabsTrigger>
            <TabsTrigger 
              value="casino" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-purple-500"
            >
              <Gamepad2 className="w-4 h-4 mr-2" />
              Casino
            </TabsTrigger>
            <TabsTrigger 
              value="sports" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-blue-500"
            >
              <Trophy className="w-4 h-4 mr-2" />
              Sports
            </TabsTrigger>
            {user.wallet >= 10000 && (
              <TabsTrigger 
                value="unique" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500"
              >
                <Star className="w-4 h-4 mr-2" />
                VIP
              </TabsTrigger>
            )}
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-teal-500"
            >
              <History className="w-4 h-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          {/* Home Tab */}
          <TabsContent value="home">
            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500 p-6">
                <h2 className="text-3xl neon-text mb-4 text-center">Welcome to BIMBETT!</h2>
                <p className="text-center text-gray-300 mb-6">Premium betting experience with exclusive bonuses</p>
                
                {/* Instagram Bonuses */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-center mb-4 text-yellow-400">🎁 Free Instagram Bonuses</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Bonus 1 */}
                    <Card className="bg-black/70 border-pink-500 p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Instagram className="w-8 h-8 text-pink-400" />
                        <div>
                          <h4 className="font-bold text-pink-400">@___bim_is_</h4>
                          <p className="text-sm text-gray-400">Follow & get 500 FRW</p>
                        </div>
                      </div>
                      
                      {!instagramBonus1 ? (
                        <Button
                          onClick={() => {
                            window.open('https://instagram.com/___bim_is_', '_blank');
                            setTimeout(async () => {
                              try {
                                const response = await fetch(
                                  `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/instagram-bonus`,
                                  {
                                    method: 'POST',
                                    headers: {
                                      'Authorization': `Bearer ${accessToken}`,
                                      'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({ account: 1 })
                                  }
                                );
                                const data = await response.json();
                                if (data.success) {
                                  onUpdateBalance(user.wallet + 500);
                                  setInstagramBonus1(true);
                                  alert('✅ 500 FRW bonus claimed!');
                                }
                              } catch (error) {
                                console.error('Bonus claim error:', error);
                              }
                            }, 60000); // 1 minute
                          }}
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
                        >
                          Follow & Claim Bonus
                        </Button>
                      ) : (
                        <div className="text-center p-2 bg-green-500/20 border border-green-500 rounded-lg">
                          <p className="text-green-400">✓ Bonus Claimed!</p>
                        </div>
                      )}
                    </Card>

                    {/* Bonus 2 */}
                    <Card className="bg-black/70 border-pink-500 p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Instagram className="w-8 h-8 text-pink-400" />
                        <div>
                          <h4 className="font-bold text-pink-400">@___bim_was_</h4>
                          <p className="text-sm text-gray-400">Follow & get 500 FRW</p>
                        </div>
                      </div>
                      
                      {!instagramBonus2 ? (
                        <Button
                          onClick={() => {
                            window.open('https://instagram.com/___bim_was_', '_blank');
                            setTimeout(async () => {
                              try {
                                const response = await fetch(
                                  `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/instagram-bonus`,
                                  {
                                    method: 'POST',
                                    headers: {
                                      'Authorization': `Bearer ${accessToken}`,
                                      'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({ account: 2 })
                                  }
                                );
                                const data = await response.json();
                                if (data.success) {
                                  onUpdateBalance(user.wallet + 500);
                                  setInstagramBonus2(true);
                                  alert('✅ 500 FRW bonus claimed!');
                                }
                              } catch (error) {
                                console.error('Bonus claim error:', error);
                              }
                            }, 60000); // 1 minute
                          }}
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
                        >
                          Follow & Claim Bonus
                        </Button>
                      ) : (
                        <div className="text-center p-2 bg-green-500/20 border border-green-500 rounded-lg">
                          <p className="text-green-400">✓ Bonus Claimed!</p>
                        </div>
                      )}
                    </Card>
                  </div>

                  <p className="text-center text-sm text-gray-400 mt-4">
                    💡 Click the button, follow the account, wait 1 minute, and your bonus will be credited automatically!
                  </p>
                </div>
              </Card>

              {/* Quick Stats */}
              <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-black/70 border-green-500 p-6 text-center">
                  <div className="text-4xl mb-2">💰</div>
                  <h3 className="text-2xl font-bold text-green-400">{user.wallet.toFixed(0)} FRW</h3>
                  <p className="text-gray-400">Your Balance</p>
                </Card>
                
                <Card className="bg-black/70 border-yellow-500 p-6 text-center">
                  <div className="text-4xl mb-2">🎮</div>
                  <h3 className="text-2xl font-bold text-yellow-400">5 Games</h3>
                  <p className="text-gray-400">Casino Games</p>
                </Card>
                
                <Card className="bg-black/70 border-cyan-500 p-6 text-center">
                  <div className="text-4xl mb-2">⚽</div>
                  <h3 className="text-2xl font-bold text-cyan-400">3 Sports</h3>
                  <p className="text-gray-400">Sports Betting</p>
                </Card>
              </div>

              {/* VIP Unlock */}
              {user.wallet < 10000 && (
                <Card className="bg-gradient-to-r from-yellow-900/50 to-orange-900/50 border-yellow-500 p-6">
                  <div className="flex items-center gap-4">
                    <Star className="w-12 h-12 text-yellow-400" />
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-yellow-400 mb-2">Unlock VIP Games!</h3>
                      <p className="text-gray-300 mb-2">Reach 10,000 FRW to access exclusive racing games with collision mechanics</p>
                      <div className="w-full bg-black/50 rounded-full h-4 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-yellow-500 to-orange-500 h-full transition-all"
                          style={{ width: `${Math.min((user.wallet / 10000) * 100, 100)}%` }}
                        />
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{user.wallet.toFixed(0)} / 10,000 FRW</p>
                    </div>
                  </div>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="casino">
            <CasinoGames 
              wallet={user.wallet}
              accessToken={accessToken}
              onUpdateBalance={onUpdateBalance}
            />
          </TabsContent>

          <TabsContent value="sports">
            <SportsBooking 
              wallet={user.wallet}
              accessToken={accessToken}
              onUpdateBalance={onUpdateBalance}
            />
          </TabsContent>

          {user.wallet >= 10000 && (
            <TabsContent value="unique">
              <UniqueGames 
                wallet={user.wallet}
                accessToken={accessToken}
                onUpdateBalance={onUpdateBalance}
              />
            </TabsContent>
          )}

          <TabsContent value="history">
            <GameHistory accessToken={accessToken} />
          </TabsContent>
        </Tabs>
      </main>

      {/* Advertisement Panel */}
      <AdvertisementPanel accessToken={accessToken} onUpdateBalance={onUpdateBalance} />

      {/* Chatbot */}
      <IBIMChatBot />

      {/* Payment Modal */}
      {showPaymentModal && (
        <PaymentModal
          type={paymentType}
          wallet={user.wallet}
          accessToken={accessToken}
          onClose={() => setShowPaymentModal(false)}
          onSuccess={(newBalance) => {
            onUpdateBalance(newBalance);
            setShowPaymentModal(false);
          }}
        />
      )}
    </div>
  );
}
