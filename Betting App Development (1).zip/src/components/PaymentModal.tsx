import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { X, DollarSign, AlertCircle } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface PaymentModalProps {
  type: 'deposit' | 'withdraw';
  wallet: number;
  accessToken: string;
  onClose: () => void;
  onSuccess: (newBalance: number) => void;
}

export function PaymentModal({ type, wallet, accessToken, onClose, onSuccess }: PaymentModalProps) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('MTN');
  const [phone, setPhone] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    setError('');
    const amountNum = parseFloat(amount);

    if (!amountNum || amountNum <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (type === 'withdraw') {
      if (wallet < 3000) {
        setError('Minimum wallet balance for withdrawal is 3000 FRW');
        return;
      }
      if (amountNum > wallet) {
        setError('Insufficient balance');
        return;
      }
      if (!phone) {
        setError('Please enter your phone number');
        return;
      }
    }

    setProcessing(true);

    try {
      const endpoint = type === 'deposit' ? 'deposit' : 'withdraw';
      const body: any = { amount: amountNum, method };
      
      if (type === 'withdraw') {
        body.phone = phone;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/${endpoint}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(body)
        }
      );

      const data = await response.json();

      if (data.success) {
        if (type === 'deposit') {
          alert(`Deposit successful!\n\nAmount: ${amountNum} FRW\nTax (12%): ${data.tax.toFixed(0)} FRW\nAdded to wallet: ${data.netAmount.toFixed(0)} FRW\n\nTax sent to: 0739980847`);
        } else {
          alert(`Withdrawal successful!\n\nAmount: ${amountNum} FRW sent to ${phone}`);
        }
        onSuccess(data.newBalance);
      } else {
        setError(data.error || 'Transaction failed');
      }
    } catch (err) {
      console.error('Payment error:', err);
      setError('An error occurred. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const calculateNet = () => {
    const amountNum = parseFloat(amount);
    if (!amountNum || type === 'withdraw') return amountNum;
    const tax = amountNum * 0.12;
    return amountNum - tax;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <Card className="w-full max-w-md bg-black/95 border-2 border-purple-500 p-6 relative">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="absolute top-2 right-2"
        >
          <X className="w-5 h-5" />
        </Button>

        <h2 className="text-2xl neon-text mb-6 text-center">
          {type === 'deposit' ? '💰 Deposit Money' : '🏦 Withdraw Money'}
        </h2>

        <div className="space-y-4">
          <div>
            <Label>Payment Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="bg-black/50 border-purple-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MTN">MTN Mobile Money</SelectItem>
                <SelectItem value="AIRTEL">AIRTEL Money</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Amount (FRW)</Label>
            <Input
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-black/50 border-purple-500"
            />
          </div>

          {type === 'withdraw' && (
            <div>
              <Label>Phone Number</Label>
              <Input
                type="tel"
                placeholder="07XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="bg-black/50 border-purple-500"
              />
              <p className="text-xs text-gray-400 mt-1">
                Enter the phone number to receive money
              </p>
            </div>
          )}

          {type === 'deposit' && amount && (
            <div className="p-4 bg-yellow-500/10 border border-yellow-500 rounded-lg">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Deposit Amount:</span>
                <span>{parseFloat(amount).toFixed(0)} FRW</span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Tax (12%):</span>
                <span className="text-red-400">-{(parseFloat(amount) * 0.12).toFixed(0)} FRW</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-yellow-500/30">
                <span className="text-green-400">You Get:</span>
                <span className="text-green-400">{calculateNet().toFixed(0)} FRW</span>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                Tax will be sent to: 0739980847
              </p>
            </div>
          )}

          {type === 'withdraw' && (
            <div className="p-3 bg-blue-500/10 border border-blue-500 rounded-lg">
              <p className="text-sm text-blue-400">
                <AlertCircle className="w-4 h-4 inline mr-1" />
                Minimum withdrawal: 3000 FRW
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Current balance: {wallet.toFixed(0)} FRW
              </p>
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500 rounded-lg">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          <div className="flex gap-2">
            <Button
              onClick={handleSubmit}
              disabled={processing}
              className={`flex-1 bg-gradient-to-r ${
                type === 'deposit' 
                  ? 'from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600'
                  : 'from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600'
              }`}
            >
              {processing ? 'Processing...' : `Confirm ${type === 'deposit' ? 'Deposit' : 'Withdrawal'}`}
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              disabled={processing}
            >
              Cancel
            </Button>
          </div>

          <p className="text-xs text-center text-gray-400">
            {type === 'deposit' 
              ? 'You will receive a mobile money prompt to confirm the transaction'
              : 'Money will be sent to your mobile money account within 5 minutes'}
          </p>
        </div>
      </Card>
    </div>
  );
}
