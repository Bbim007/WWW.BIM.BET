import { motion } from 'motion/react';

export function AnimatedLogo({ size = 'large' }: { size?: 'small' | 'large' }) {
  const isSmall = size === 'small';
  const fontSize = isSmall ? 'text-2xl' : 'text-6xl md:text-8xl';
  const containerClass = isSmall ? 'h-12' : 'h-32';

  return (
    <div className={`relative flex items-center justify-center ${containerClass}`}>
      <div className="relative inline-flex items-center" style={{ fontFamily: "'Orbitron', sans-serif" }}>
        {/* B letter - always visible with 3D effect */}
        <motion.span
          className={`${fontSize} font-black relative inline-block`}
          style={{
            background: 'linear-gradient(145deg, #fbbf24, #f59e0b, #d97706)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            textShadow: '0 0 30px rgba(251, 191, 36, 0.5)',
            filter: 'drop-shadow(0 10px 20px rgba(251, 191, 36, 0.3))'
          }}
          animate={{
            rotateY: [0, 5, 0, -5, 0],
            scale: [1, 1.05, 1, 1.05, 1]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          B
          {/* 3D layers effect */}
          <span 
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(145deg, #ef4444, #dc2626)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              transform: 'translateZ(-10px) translateX(-2px) translateY(2px)',
              opacity: 0.3,
              filter: 'blur(1px)'
            }}
          >
            B
          </span>
        </motion.span>

        {/* !MBETT letters - always visible with individual animations */}
        <motion.span
          className={`${fontSize} font-black inline-block`}
          style={{
            background: 'linear-gradient(145deg, #06b6d4, #0891b2, #0e7490)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            textShadow: '0 0 30px rgba(6, 182, 212, 0.5)',
            filter: 'drop-shadow(0 10px 20px rgba(6, 182, 212, 0.3))'
          }}
        >
          <motion.span
            className="inline-block"
            animate={{
              rotateZ: [0, -5, 5, 0],
              y: [0, -3, 3, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            !
          </motion.span>
          <motion.span
            className="inline-block"
            animate={{
              rotateY: [0, 10, -10, 0]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.1
            }}
          >
            M
          </motion.span>
          <motion.span
            className="inline-block"
            animate={{
              scale: [1, 1.1, 1]
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.2
            }}
          >
            B
          </motion.span>
          <motion.span
            className="inline-block"
            animate={{
              rotateY: [0, -10, 10, 0]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.3
            }}
          >
            E
          </motion.span>
          <motion.span
            className="inline-block"
            animate={{
              y: [0, -5, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.4
            }}
          >
            T
          </motion.span>
          <motion.span
            className="inline-block"
            animate={{
              rotateZ: [0, 5, -5, 0]
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5
            }}
          >
            T
          </motion.span>
        </motion.span>

        {/* Floating particles effect */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-yellow-400 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [-20, -40, -20],
                x: [0, Math.random() * 20 - 10, 0],
                opacity: [0, 1, 0],
                scale: [0, 1.5, 0]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.5,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
      </div>

      {/* Glow effect - removed blur */}
      <motion.div
        className="absolute inset-0 opacity-20"
        style={{
          background: 'radial-gradient(circle, rgba(251, 191, 36, 0.4), rgba(6, 182, 212, 0.3), transparent)'
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.15, 0.3, 0.15]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </div>
  );
}
