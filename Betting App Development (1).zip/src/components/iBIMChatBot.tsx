import { useState, useRef, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

export function IBIMChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm iBIM AI, your BIMBETT assistant. How can I help you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase();

    // Owner/About queries
    if (msg.includes('owner') || msg.includes('creator') || msg.includes('who made') || msg.includes('who created')) {
      return "BIMBETT was created by our amazing founder! Check out their Instagram profiles:\n\n@___bim_is_ - https://instagram.com/___bim_is_\n@___bim_was_ - https://instagram.com/___bim_was_\n\nFollow them for exclusive updates and bonuses! 🎁";
    }

    // Casino games
    if (msg.includes('spin') || msg.includes('wheel')) {
      return "🎡 Spin Wheel: Place your bet and spin the wheel! Land on a multiplier to win up to 5x your bet. The wheel has different zones with various multipliers. Good luck!";
    }

    if (msg.includes('crash') || msg.includes('aviator')) {
      return "✈️ Aviator Crash: Watch the plane fly and the multiplier grow! Cash out before it crashes to secure your winnings. The longer you wait, the higher the multiplier - but be careful, it can crash anytime!";
    }

    if (msg.includes('slot')) {
      return "🎰 Slots: Classic slot machine game! Match 3 symbols to win. Different symbol combinations give different multipliers. Three 7s give you the jackpot!";
    }

    if (msg.includes('blackjack') || msg.includes('21')) {
      return "🃏 Blackjack: Coming soon! Classic card game where you aim to get as close to 21 as possible without going over. Beat the dealer to win!";
    }

    if (msg.includes('rolling') || msg.includes('ball')) {
      return "⚽ Rolling Ball: Watch the ball roll with realistic physics! Land it in the green target zone to win up to 4x your bet. The ball bounces and slows down naturally - timing is everything!";
    }

    // VIP/Unique games
    if (msg.includes('vip') || msg.includes('unique') || msg.includes('car') || msg.includes('racing')) {
      return "🏎️ VIP Games (10,000+ FRW required):\n• Car Racing - Dodge falling cars and obstacles\n• Plane Racing - Navigate through the skies\n• Horse Racing - Classic race betting\n\nAll feature realistic collision mechanics. Follow our Instagram accounts for bonus rewards!";
    }

    // Sports betting
    if (msg.includes('sport') || msg.includes('football') || msg.includes('basketball') || msg.includes('volleyball')) {
      return "⚽🏀🏐 Sports Betting: Bet on live matches for Football, Basketball, and Volleyball. Choose your team and pick the outcome (Home Win, Draw, Away Win). Each team has different multipliers based on their strength!";
    }

    // Payment/Money
    if (msg.includes('deposit') || msg.includes('add money') || msg.includes('fund')) {
      return "💰 Deposits: Use MTN or AIRTEL mobile money to deposit funds. Click the wallet icon and select 'Deposit'. Minimum deposit varies by provider.";
    }

    if (msg.includes('withdraw') || msg.includes('cash out') || msg.includes('take money')) {
      return "💵 Withdrawals: Minimum withdrawal is 3000 FRW. A 12% tax applies to all withdrawals. Click the wallet icon and select 'Withdraw' to process your payout via mobile money.";
    }

    if (msg.includes('bonus') || msg.includes('free money') || msg.includes('reward')) {
      return "🎁 Bonuses:\n• 1000 FRW signup bonus for new users\n• Instagram Follow Bonus: Follow @___bim_is_ and @___bim_was_, wait 1 minute, then claim 500 FRW per account!\n• VIP members get exclusive racing games with higher multipliers!";
    }

    // Instagram bonus
    if (msg.includes('instagram') || msg.includes('follow') || msg.includes('ig')) {
      return "📱 Instagram Bonuses: Follow our accounts and earn rewards!\n\n@___bim_is_ - Follow and claim 500 FRW\n@___bim_was_ - Follow and claim 500 FRW\n\nAfter following, wait 1 minute and click the bonus button on the home screen. That's 1000 FRW in free bonuses! 🎉";
    }

    // General help
    if (msg.includes('how') || msg.includes('help') || msg.includes('start') || msg.includes('play')) {
      return "🎮 How to Play:\n1. Choose a game from Casino, Sports, or VIP section\n2. Place your bet amount\n3. Play and try to win!\n4. Cash out your winnings\n\nNeed help with a specific game? Just ask me about it!";
    }

    if (msg.includes('balance') || msg.includes('wallet') || msg.includes('money')) {
      return "💼 Your wallet shows your current balance in FRW. You can deposit via mobile money or withdraw (minimum 3000 FRW with 12% tax). Your balance updates in real-time as you play!";
    }

    if (msg.includes('age') || msg.includes('old') || msg.includes('young')) {
      return "🔞 BIMBETT is for players 10 years and older only. Please gamble responsibly!";
    }

    if (msg.includes('safe') || msg.includes('secure') || msg.includes('legit')) {
      return "🔒 BIMBETT is a secure betting platform. All transactions are protected, and game outcomes are fair. Play responsibly and never bet more than you can afford to lose!";
    }

    // Default response
    return "I'm here to help! You can ask me about:\n• Games (Spin Wheel, Aviator, Slots, Sports, VIP Games)\n• Payments (Deposits, Withdrawals, Bonuses)\n• Instagram bonuses (@___bim_is_ & @___bim_was_)\n• The owner/creator of BIMBETT\n• How to play\n\nWhat would you like to know?";
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Bot response after a short delay
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(inputValue),
        isBot: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-2xl relative overflow-hidden"
            >
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 10, -10, 0]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Bot className="w-8 h-8" />
              </motion.div>
              
              {/* Notification pulse */}
              <motion.div
                className="absolute inset-0 rounded-full bg-pink-500/50"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 0, 0.5]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)]"
          >
            <Card className="bg-black/95 border-purple-500 overflow-hidden shadow-2xl backdrop-blur-xl">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <motion.div
                    animate={{
                      rotate: [0, 360]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  >
                    <Bot className="w-6 h-6" />
                  </motion.div>
                  <div>
                    <h3 className="font-bold">iBIM AI</h3>
                    <p className="text-xs opacity-90">Your BIMBETT Assistant</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-white/20"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl ${
                        message.isBot
                          ? 'bg-purple-500/20 border border-purple-500/50'
                          : 'bg-pink-500/20 border border-pink-500/50'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-line">{message.text}</p>
                      <p className="text-xs opacity-50 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t border-purple-500/30">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask me anything..."
                    className="bg-black/50 border-purple-500/50 focus:border-purple-500"
                  />
                  <Button
                    onClick={handleSend}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
