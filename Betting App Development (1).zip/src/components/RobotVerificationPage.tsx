import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Shield } from 'lucide-react';

interface RobotVerificationPageProps {
  onVerify: () => void;
}

export function RobotVerificationPage({ onVerify }: RobotVerificationPageProps) {
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');

  const handleVerify = () => {
    if (answer.toLowerCase().trim() === 'spider') {
      onVerify();
    } else {
      setError('Incorrect answer. Try again!');
      setAnswer('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0a0015] p-4">
      {/* Background animated elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-72 h-72 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 neon-border bg-black/90 backdrop-blur-xl p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-green-500/20 rounded-full">
              <Shield className="w-12 h-12 text-green-400" />
            </div>
          </div>
          <h2 className="neon-text mb-2">Robot Verification</h2>
          <p className="text-gray-400">Prove you're human</p>
        </div>

        <div className="space-y-6">
          <div className="p-4 bg-purple-500/10 border border-purple-500 rounded-lg">
            <p className="text-center text-lg text-cyan-400">
              Which animal has eight legs and hair?
            </p>
          </div>

          <div>
            <Label>Your Answer</Label>
            <Input
              type="text"
              placeholder="Type your answer..."
              value={answer}
              onChange={(e) => {
                setAnswer(e.target.value);
                setError('');
              }}
              onKeyPress={(e) => e.key === 'Enter' && handleVerify()}
              className="bg-black/50 border-purple-500"
            />
          </div>

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500 rounded-md">
              <p className="text-red-400 text-sm text-center">{error}</p>
            </div>
          )}

          <Button 
            onClick={handleVerify} 
            className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
            disabled={!answer.trim()}
          >
            Verify
          </Button>

          <p className="text-xs text-center text-gray-400">
            Think carefully! This protects BIMBETT from bots.
          </p>
        </div>
      </Card>
    </div>
  );
}
