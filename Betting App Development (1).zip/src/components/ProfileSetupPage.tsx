import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { User, Upload, Instagram } from 'lucide-react';

interface ProfileSetupPageProps {
  onComplete: (username: string, avatar: string) => void;
}

const avatars = [
  { id: 'male', label: 'Male', emoji: '👨' },
  { id: 'female', label: 'Female', emoji: '👩' },
  { id: 'oldmale', label: 'Old Male', emoji: '👴' },
  { id: 'oldfemale', label: 'Old Female', emoji: '👵' }
];

export function ProfileSetupPage({ onComplete }: ProfileSetupPageProps) {
  const [username, setUsername] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image must be less than 5MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setSelectedAvatar('custom');
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleInstagramImport = () => {
    window.open('https://instagram.com/___bim_is_', '_blank');
    alert('Please save your Instagram profile picture and upload it using the Upload button below. You can also get a bonus by following us!');
  };

  const handleComplete = () => {
    // Validate username has at least one number
    const hasNumber = /\d/.test(username);
    if (!hasNumber) {
      setError('Username must contain at least one number');
      return;
    }

    if (username.length < 3) {
      setError('Username must be at least 3 characters');
      return;
    }

    if (!selectedAvatar) {
      setError('Please select an avatar or upload a picture');
      return;
    }

    const avatarData = uploadedImage || selectedAvatar;
    onComplete(username, avatarData);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0a0015] p-4">
      {/* Background animated elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 neon-border bg-black/90 backdrop-blur-xl p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-purple-500/20 rounded-full">
              <User className="w-12 h-12 text-purple-400" />
            </div>
          </div>
          <h2 className="neon-text mb-2">Setup Profile</h2>
          <p className="text-gray-400">Personalize your BIMBETT account</p>
        </div>

        <div className="space-y-6">
          <div>
            <Label>Username</Label>
            <Input
              type="text"
              placeholder="e.g., Player123"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setError('');
              }}
              className="bg-black/50 border-purple-500"
            />
            <p className="text-xs text-gray-400 mt-1">Must include at least one number</p>
          </div>

          <div>
            <Label className="mb-3 block">Choose Avatar or Upload Picture</Label>
            
            {/* Upload Options */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="border-cyan-500 hover:bg-cyan-500/20"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload from Device
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleInstagramImport}
                className="border-pink-500 hover:bg-pink-500/20"
              >
                <Instagram className="w-4 h-4 mr-2" />
                From Instagram
              </Button>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Show uploaded image */}
            {uploadedImage && (
              <div className="mb-4 text-center">
                <div className="inline-block p-2 bg-green-500/20 border-2 border-green-500 rounded-lg">
                  <img src={uploadedImage} alt="Uploaded" className="w-24 h-24 rounded-full object-cover" />
                  <p className="text-xs text-green-400 mt-2">✓ Custom Picture</p>
                </div>
              </div>
            )}

            {/* Avatar Grid */}
            <div className="grid grid-cols-2 gap-3">
              {avatars.map((avatar) => (
                <button
                  key={avatar.id}
                  type="button"
                  onClick={() => {
                    setSelectedAvatar(avatar.id);
                    setUploadedImage(null);
                    setError('');
                  }}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedAvatar === avatar.id && !uploadedImage
                      ? 'border-pink-500 bg-pink-500/20 scale-105'
                      : 'border-purple-500/30 bg-black/30 hover:border-purple-500'
                  }`}
                >
                  <div className="text-4xl mb-2">{avatar.emoji}</div>
                  <div className="text-sm text-gray-300">{avatar.label}</div>
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500 rounded-md">
              <p className="text-red-400 text-sm text-center">{error}</p>
            </div>
          )}

          <div className="p-4 bg-green-500/10 border border-green-500 rounded-lg text-center">
            <p className="text-green-400">🎁 Welcome Bonus</p>
            <p className="text-2xl text-green-300 mt-1">1000 FRW</p>
            <p className="text-xs text-gray-400 mt-1">Added to your wallet instantly!</p>
          </div>

          <Button 
            onClick={handleComplete} 
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Complete Setup & Start Playing!
          </Button>
        </div>
      </Card>
    </div>
  );
}
