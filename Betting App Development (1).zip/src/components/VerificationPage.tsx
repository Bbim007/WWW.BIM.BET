import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Label } from './ui/label';

interface VerificationPageProps {
  identifier: string;
  verificationCode: string;
  onVerify: (code: string) => void;
}

export function VerificationPage({ identifier, verificationCode, onVerify }: VerificationPageProps) {
  const [code, setCode] = useState('');
  const [showHint, setShowHint] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0a0015] p-4">
      {/* Background animated elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-72 h-72 bg-pink-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 neon-border bg-black/90 backdrop-blur-xl p-8">
        <div className="text-center mb-8">
          <h2 className="neon-text mb-2">Verification</h2>
          <p className="text-gray-400">Enter the code sent to</p>
          <p className="text-cyan-400">{identifier}</p>
        </div>

        <div className="space-y-6">
          <div>
            <Label>Verification Code</Label>
            <Input
              type="text"
              placeholder="e.g., 07rx"
              value={code}
              onChange={(e) => setCode(e.target.value.toLowerCase())}
              maxLength={4}
              className="bg-black/50 border-purple-500 text-center text-2xl tracking-widest"
            />
            <p className="text-xs text-gray-400 mt-2">
              Format: 2 numbers + 2 letters (e.g., 07rx)
            </p>
          </div>

          {/* Demo hint */}
          {!showHint && (
            <Button
              type="button"
              variant="ghost"
              onClick={() => setShowHint(true)}
              className="w-full text-yellow-400"
            >
              Show Demo Code
            </Button>
          )}
          
          {showHint && (
            <div className="p-3 bg-yellow-500/10 border border-yellow-500 rounded-md">
              <p className="text-yellow-400 text-sm text-center">
                Demo Code: <span className="tracking-widest">{verificationCode}</span>
              </p>
            </div>
          )}

          <Button 
            onClick={() => onVerify(code)} 
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
            disabled={code.length !== 4}
          >
            Verify & Continue
          </Button>

          <div className="text-center">
            <Button variant="link" className="text-cyan-400">
              Resend Code
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
