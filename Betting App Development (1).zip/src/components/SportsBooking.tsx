import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Trophy, Calendar, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface SportsBookingProps {
  wallet: number;
  accessToken: string;
  onUpdateBalance: (newBalance: number) => void;
}

export function SportsBooking({ wallet, accessToken, onUpdateBalance }: SportsBookingProps) {
  const [matches, setMatches] = useState<any>({ football: [], basketball: [], volleyball: [] });
  const [selectedMatch, setSelectedMatch] = useState<any>(null);
  const [betAmount, setBetAmount] = useState('100');
  const [selectedOutcome, setSelectedOutcome] = useState<string>('');

  useEffect(() => {
    fetchMatches();
  }, []);

  const fetchMatches = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/sports-matches`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      const data = await response.json();
      if (data.success) {
        setMatches(data.matches);
      }
    } catch (error) {
      console.error('Fetch matches error:', error);
    }
  };

  const handlePlaceBet = async () => {
    if (!selectedMatch || !selectedOutcome) return;

    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      alert('Insufficient balance!');
      return;
    }

    // Place bet
    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          gameType: 'sports', 
          betAmount: bet, 
          gameData: { match: selectedMatch, outcome: selectedOutcome }
        })
      }
    );

    // Simulate outcome (in production, this would be resolved when match ends)
    const win = Math.random() > 0.6; // 40% win chance
    
    if (win) {
      const odds = selectedOutcome === 'home' ? selectedMatch.homeOdds 
                  : selectedOutcome === 'away' ? selectedMatch.awayOdds 
                  : selectedMatch.drawOdds;
      const winAmount = bet * odds;

      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ 
            betId: 'sports_' + Date.now(), 
            winAmount, 
            gameType: 'sports',
            gameData: { match: selectedMatch, outcome: selectedOutcome, odds }
          })
        }
      );

      alert(`You won ${winAmount.toFixed(0)} FRW!`);
      onUpdateBalance(wallet - bet + winAmount);
    } else {
      alert('Better luck next time!');
      onUpdateBalance(wallet - bet);
    }

    setSelectedMatch(null);
    setSelectedOutcome('');
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl neon-text mb-2">Sports Betting</h2>
        <p className="text-gray-400">Bet on your favorite teams!</p>
      </div>

      <Tabs defaultValue="football" className="space-y-4">
        <TabsList className="bg-black/50 backdrop-blur-lg border border-cyan-500/30">
          <TabsTrigger value="football">⚽ Football</TabsTrigger>
          <TabsTrigger value="basketball">🏀 Basketball</TabsTrigger>
          <TabsTrigger value="volleyball">🏐 Volleyball</TabsTrigger>
        </TabsList>

        <TabsContent value="football">
          <MatchList 
            matches={matches.football} 
            sport="football"
            onSelectMatch={setSelectedMatch}
            selectedMatch={selectedMatch}
          />
        </TabsContent>

        <TabsContent value="basketball">
          <MatchList 
            matches={matches.basketball} 
            sport="basketball"
            onSelectMatch={setSelectedMatch}
            selectedMatch={selectedMatch}
          />
        </TabsContent>

        <TabsContent value="volleyball">
          <MatchList 
            matches={matches.volleyball} 
            sport="volleyball"
            onSelectMatch={setSelectedMatch}
            selectedMatch={selectedMatch}
          />
        </TabsContent>
      </Tabs>

      {/* Bet Slip */}
      {selectedMatch && (
        <Card className="bg-black/70 border-green-500 p-6 sticky bottom-4">
          <h3 className="text-xl mb-4 text-center neon-text">Place Your Bet</h3>
          
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-gray-400 text-sm">{selectedMatch.home} vs {selectedMatch.away}</p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={selectedOutcome === 'home' ? 'default' : 'outline'}
                onClick={() => setSelectedOutcome('home')}
                className={selectedOutcome === 'home' ? 'bg-cyan-500' : ''}
              >
                <div className="text-center w-full">
                  <div className="text-xs">Home</div>
                  <div className="text-lg">{selectedMatch.homeOdds}x</div>
                </div>
              </Button>

              {selectedMatch.drawOdds && (
                <Button
                  variant={selectedOutcome === 'draw' ? 'default' : 'outline'}
                  onClick={() => setSelectedOutcome('draw')}
                  className={selectedOutcome === 'draw' ? 'bg-yellow-500' : ''}
                >
                  <div className="text-center w-full">
                    <div className="text-xs">Draw</div>
                    <div className="text-lg">{selectedMatch.drawOdds}x</div>
                  </div>
                </Button>
              )}

              <Button
                variant={selectedOutcome === 'away' ? 'default' : 'outline'}
                onClick={() => setSelectedOutcome('away')}
                className={selectedOutcome === 'away' ? 'bg-pink-500' : ''}
              >
                <div className="text-center w-full">
                  <div className="text-xs">Away</div>
                  <div className="text-lg">{selectedMatch.awayOdds}x</div>
                </div>
              </Button>
            </div>

            <div>
              <label className="block text-sm mb-2">Bet Amount (FRW)</label>
              <Input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                className="bg-black/50 border-green-500"
              />
            </div>

            {selectedOutcome && (
              <div className="p-3 bg-green-500/20 border border-green-500 rounded-lg text-center">
                <p className="text-sm text-gray-400">Potential Win</p>
                <p className="text-2xl text-green-400">
                  {(parseFloat(betAmount) * (
                    selectedOutcome === 'home' ? selectedMatch.homeOdds 
                    : selectedOutcome === 'away' ? selectedMatch.awayOdds 
                    : selectedMatch.drawOdds
                  )).toFixed(0)} FRW
                </p>
              </div>
            )}

            <div className="flex gap-2">
              <Button
                onClick={handlePlaceBet}
                disabled={!selectedOutcome}
                className="flex-1 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600"
              >
                Place Bet
              </Button>
              <Button
                onClick={() => {
                  setSelectedMatch(null);
                  setSelectedOutcome('');
                }}
                variant="outline"
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

function MatchList({ matches, sport, onSelectMatch, selectedMatch }: any) {
  return (
    <div className="grid gap-4">
      {matches.map((match: any) => (
        <Card 
          key={match.id}
          className={`bg-black/70 border-2 p-4 cursor-pointer transition-all ${
            selectedMatch?.id === match.id 
              ? 'border-cyan-500 bg-cyan-500/10' 
              : 'border-purple-500/30 hover:border-purple-500'
          }`}
          onClick={() => onSelectMatch(match)}
        >
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 text-center">
              <p className="text-lg">{match.home}</p>
              <Badge className="bg-cyan-500/20 border-cyan-500 mt-1">
                {match.homeOdds}x
              </Badge>
            </div>

            <div className="flex flex-col items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-400" />
              <div className="text-xs text-gray-400 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {match.time}
              </div>
              {match.drawOdds && (
                <Badge className="bg-yellow-500/20 border-yellow-500">
                  Draw {match.drawOdds}x
                </Badge>
              )}
            </div>

            <div className="flex-1 text-center">
              <p className="text-lg">{match.away}</p>
              <Badge className="bg-pink-500/20 border-pink-500 mt-1">
                {match.awayOdds}x
              </Badge>
            </div>
          </div>
        </Card>
      ))}

      {matches.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          <p>No matches available at the moment</p>
          <p className="text-sm mt-2">Check back soon!</p>
        </div>
      )}
    </div>
  );
}
