import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { DollarSign, Zap, Play, RotateCw } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface CasinoGamesProps {
  wallet: number;
  accessToken: string;
  onUpdateBalance: (newBalance: number) => void;
}

export function CasinoGames({ wallet, accessToken, onUpdateBalance }: CasinoGamesProps) {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  const games = [
    { id: 'spin', name: 'Spin Wheel', icon: '🎡', color: 'from-pink-500 to-purple-500' },
    { id: 'crash', name: 'Aviator Crash', icon: '✈️', color: 'from-cyan-500 to-blue-500' },
    { id: 'slots', name: 'Slots', icon: '🎰', color: 'from-yellow-500 to-orange-500' },
    { id: 'blackjack', name: 'Blackjack', icon: '🃏', color: 'from-red-500 to-pink-500' },
    { id: 'rolling', name: 'Rolling Ball', icon: '⚽', color: 'from-green-500 to-teal-500' }
  ];

  return (
    <div className="space-y-6">
      {!selectedGame ? (
        <>
          <div className="text-center">
            <h2 className="text-3xl neon-text mb-2">Casino Games</h2>
            <p className="text-gray-400">Choose your game and win big!</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.05,
                  rotateY: 5,
                  rotateX: -5,
                }}
                whileTap={{ scale: 0.95 }}
                style={{ perspective: 1000 }}
              >
                <Card
                  className="cursor-pointer bg-black/70 border-2 border-purple-500/30 hover:border-purple-500 transition-all p-6 relative overflow-hidden group"
                  onClick={() => setSelectedGame(game.id)}
                >
                  {/* Floating icon with 3D effect */}
                  <motion.div 
                    className="relative mb-4"
                    animate={{
                      y: [0, -10, 0],
                      rotateZ: [0, 5, 0, -5, 0]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    <div 
                      className={`text-7xl text-center bg-gradient-to-r ${game.color} bg-clip-text text-transparent`}
                      style={{
                        filter: 'drop-shadow(0 10px 30px rgba(251, 191, 36, 0.5))',
                        textShadow: '0 0 40px rgba(251, 191, 36, 0.8)'
                      }}
                    >
                      {game.icon}
                    </div>
                    {/* 3D Shadow layer */}
                    <div 
                      className="absolute inset-0 text-7xl text-center opacity-20 blur-sm"
                      style={{ transform: 'translateZ(-10px) translateY(5px)' }}
                    >
                      {game.icon}
                    </div>
                  </motion.div>

                  <h3 className="text-center text-xl mb-3 font-bold">{game.name}</h3>
                  
                  <Button className={`w-full bg-gradient-to-r ${game.color} relative overflow-hidden group-hover:shadow-2xl transition-shadow`}>
                    <motion.span
                      className="absolute inset-0 bg-white/20"
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.5 }}
                    />
                    <Play className="w-4 h-4 mr-2 relative z-10" />
                    <span className="relative z-10">Play Now</span>
                  </Button>

                  {/* Glowing particles */}
                  <div className="absolute inset-0 pointer-events-none">
                    {[...Array(3)].map((_, i) => (
                      <motion.div
                        key={i}
                        className={`absolute w-2 h-2 bg-gradient-to-r ${game.color} rounded-full`}
                        style={{
                          left: `${20 + i * 30}%`,
                          top: '50%'
                        }}
                        animate={{
                          y: [-20, -40, -20],
                          opacity: [0, 1, 0],
                          scale: [0, 1.5, 0]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: i * 0.3,
                          ease: "easeInOut"
                        }}
                      />
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </>
      ) : (
        <div>
          <Button
            variant="outline"
            onClick={() => setSelectedGame(null)}
            className="mb-4"
          >
            ← Back to Games
          </Button>

          {selectedGame === 'spin' && (
            <SpinWheelGame 
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'crash' && (
            <CrashGame 
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'slots' && (
            <SlotsGame 
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'blackjack' && (
            <BlackjackGame 
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'rolling' && (
            <RollingBallGame 
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
        </div>
      )}
    </div>
  );
}

// Spin Wheel Game
function SpinWheelGame({ wallet, accessToken, onUpdateBalance }: any) {
  const [betAmount, setBetAmount] = useState('100');
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [rotation, setRotation] = useState(0);

  const multipliers = [0.1, 0.2, 0.5, 0.11, 1.0, 1.5, 2.0, 3.0, 5.0, 0.01];

  const handleSpin = async () => {
    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      alert('Insufficient balance!');
      return;
    }

    setSpinning(true);
    setResult(null);

    // Place bet
    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gameType: 'spin', betAmount: bet, gameData: {} })
      }
    );

    // Animate spin
    const spins = 5 + Math.random() * 3;
    const randomMultiplier = multipliers[Math.floor(Math.random() * multipliers.length)];
    const newRotation = rotation + spins * 360 + (Math.random() * 360);
    
    setRotation(newRotation);

    setTimeout(async () => {
      setSpinning(false);
      const winAmount = bet * randomMultiplier;

      if (winAmount > 0) {
        // Win
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
              betId: 'spin_' + Date.now(), 
              winAmount, 
              gameType: 'spin',
              gameData: { multiplier: randomMultiplier }
            })
          }
        );
      }

      setResult({ multiplier: randomMultiplier, winAmount });
      onUpdateBalance(wallet - bet + winAmount);
    }, 3000);
  };

  return (
    <Card className="bg-black/70 border-pink-500 p-6">
      <h3 className="text-2xl neon-text mb-6 text-center">🎡 Spin Wheel</h3>

      <div className="max-w-md mx-auto space-y-6">
        <div className="relative w-64 h-64 mx-auto">
          <motion.div
            animate={{ rotate: rotation }}
            transition={{ duration: 3, ease: "easeOut" }}
            className="w-full h-full rounded-full border-8 border-pink-500"
            style={{
              background: `conic-gradient(
                from 0deg,
                #ec4899 0deg 36deg,
                #8b5cf6 36deg 72deg,
                #06b6d4 72deg 108deg,
                #f59e0b 108deg 144deg,
                #10b981 144deg 180deg,
                #ec4899 180deg 216deg,
                #8b5cf6 216deg 252deg,
                #06b6d4 252deg 288deg,
                #f59e0b 288deg 324deg,
                #10b981 324deg 360deg
              )`
            }}
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-yellow-400 z-10"></div>
          </motion.div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-black rounded-full w-16 h-16 flex items-center justify-center text-2xl">
              🎯
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm mb-2">Bet Amount (FRW)</label>
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            className="bg-black/50 border-pink-500"
            disabled={spinning}
          />
        </div>

        <Button
          onClick={handleSpin}
          disabled={spinning}
          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
        >
          {spinning ? (
            <>
              <RotateCw className="w-4 h-4 mr-2 animate-spin" />
              Spinning...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Spin ({betAmount} FRW)
            </>
          )}
        </Button>

        {result && (
          <div className={`p-4 rounded-lg border-2 text-center ${
            result.winAmount >= parseFloat(betAmount) 
              ? 'bg-green-500/20 border-green-500' 
              : 'bg-red-500/20 border-red-500'
          }`}>
            <p className="text-2xl mb-2">{result.multiplier}x</p>
            <p className={result.winAmount >= parseFloat(betAmount) ? 'text-green-400' : 'text-red-400'}>
              {result.winAmount >= parseFloat(betAmount) ? 'Won' : 'Lost'}: {result.winAmount.toFixed(0)} FRW
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}

// Crash Game (Aviator)
function CrashGame({ wallet, accessToken, onUpdateBalance }: any) {
  const [betAmount, setBetAmount] = useState('100');
  const [playing, setPlaying] = useState(false);
  const [multiplier, setMultiplier] = useState(1.00);
  const [crashed, setCrashed] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [planePosition, setPlanePosition] = useState({ x: 10, y: 80 });
  const [planeRotation, setPlaneRotation] = useState(0);
  const intervalRef = useRef<any>(null);

  const handleStart = async () => {
    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      alert('Insufficient balance!');
      return;
    }

    setPlaying(true);
    setCrashed(false);
    setResult(null);
    setMultiplier(1.00);
    setPlanePosition({ x: 10, y: 80 });
    setPlaneRotation(-15);

    // Place bet
    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gameType: 'crash', betAmount: bet, gameData: {} })
      }
    );

    // Random crash point between 1.5x and 10x
    const crashPoint = 1.5 + Math.random() * 8.5;
    let currentMultiplier = 1.00;

    intervalRef.current = setInterval(() => {
      currentMultiplier += 0.01;
      
      if (currentMultiplier >= crashPoint) {
        clearInterval(intervalRef.current);
        setCrashed(true);
        setPlaying(false);
        setPlaneRotation(90);
        setResult({ crashed: true, crashPoint });
        onUpdateBalance(wallet - bet);
      } else {
        setMultiplier(currentMultiplier);
        // Update plane position (fly up and to the right)
        setPlanePosition({
          x: 10 + (currentMultiplier - 1) * 15,
          y: 80 - (currentMultiplier - 1) * 12
        });
      }
    }, 100);
  };

  const handleCashout = async () => {
    if (!playing) return;

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    setPlaying(false);
    const winAmount = parseFloat(betAmount) * multiplier;

    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          betId: 'crash_' + Date.now(), 
          winAmount, 
          gameType: 'crash',
          gameData: { multiplier }
        })
      }
    );

    setResult({ crashed: false, multiplier, winAmount });
    onUpdateBalance(wallet - parseFloat(betAmount) + winAmount);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return (
    <Card className="bg-black/70 border-cyan-500 p-6">
      <h3 className="text-2xl neon-text mb-6 text-center">✈️ Aviator Crash</h3>

      <div className="max-w-3xl mx-auto space-y-6">
        {/* Flight Area */}
        <div className="relative h-96 bg-gradient-to-b from-blue-900 via-cyan-900 to-blue-950 rounded-xl overflow-hidden border-2 border-cyan-500">
          {/* Clouds */}
          <div className="absolute inset-0">
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-4xl opacity-20"
                style={{
                  left: `${20 + i * 20}%`,
                  top: `${10 + i * 15}%`
                }}
                animate={{
                  x: [0, 50, 0],
                  opacity: [0.2, 0.4, 0.2]
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  delay: i * 0.5,
                  ease: "easeInOut"
                }}
              >
                ☁️
              </motion.div>
            ))}
          </div>

          {/* Grid for depth */}
          <div className="absolute inset-0 opacity-10">
            {[...Array(10)].map((_, i) => (
              <div
                key={i}
                className="absolute w-full h-px bg-cyan-400"
                style={{ top: `${i * 10}%` }}
              />
            ))}
          </div>

          {/* Multiplier Display */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10">
            <motion.div
              className={`text-6xl font-black ${crashed ? 'text-red-500' : 'text-cyan-400'}`}
              animate={{
                scale: playing && !crashed ? [1, 1.1, 1] : 1
              }}
              transition={{
                duration: 0.5,
                repeat: playing && !crashed ? Infinity : 0
              }}
              style={{
                textShadow: '0 0 30px rgba(6, 182, 212, 0.8), 0 0 60px rgba(6, 182, 212, 0.5)'
              }}
            >
              {multiplier.toFixed(2)}x
            </motion.div>
          </div>

          {/* Flying Plane */}
          <motion.div
            className="absolute"
            style={{
              left: `${planePosition.x}%`,
              top: `${planePosition.y}%`,
              transform: `rotate(${planeRotation}deg)`
            }}
            animate={crashed ? {
              y: [0, 100],
              rotate: [planeRotation, planeRotation + 180],
              opacity: [1, 0]
            } : {}}
            transition={{
              duration: 1.5,
              ease: "easeIn"
            }}
          >
            <div className="relative">
              {/* Plane trail */}
              {playing && !crashed && (
                <motion.div
                  className="absolute -left-20 top-1/2 w-20 h-1 bg-gradient-to-r from-transparent to-cyan-400"
                  animate={{
                    opacity: [0, 1, 0],
                    scaleX: [0, 1, 0]
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                    ease: "easeOut"
                  }}
                />
              )}
              
              {/* Plane */}
              <div 
                className="text-7xl"
                style={{
                  filter: 'drop-shadow(0 10px 30px rgba(6, 182, 212, 0.7))'
                }}
              >
                ✈️
              </div>

              {/* Explosion effect */}
              {crashed && (
                <motion.div
                  className="absolute inset-0 text-6xl"
                  initial={{ scale: 0, opacity: 1 }}
                  animate={{ scale: 3, opacity: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  💥
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Crash Message */}
          {crashed && (
            <motion.div
              className="absolute inset-0 flex items-center justify-center bg-black/70"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="text-center">
                <motion.p
                  className="text-6xl font-black text-red-500 mb-4"
                  animate={{
                    scale: [1, 1.2, 1],
                    rotate: [-5, 5, -5]
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: 3
                  }}
                  style={{
                    textShadow: '0 0 40px rgba(239, 68, 68, 0.8)'
                  }}
                >
                  CRASHED!
                </motion.p>
                <p className="text-2xl text-red-400">@ {result?.crashPoint?.toFixed(2)}x</p>
              </div>
            </motion.div>
          )}

          {/* Flight path visualization */}
          {playing && !crashed && (
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <motion.path
                d={`M ${planePosition.x * 10} ${planePosition.y * 3.8} Q ${planePosition.x * 10 - 100} ${planePosition.y * 3.8 + 50} ${planePosition.x * 10 - 200} ${planePosition.y * 3.8 + 100}`}
                stroke="rgba(6, 182, 212, 0.3)"
                strokeWidth="3"
                fill="none"
                strokeDasharray="10 5"
              />
            </svg>
          )}
        </div>

        {!playing && !crashed && (
          <div>
            <label className="block text-sm mb-2">Bet Amount (FRW)</label>
            <Input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              className="bg-black/50 border-cyan-500"
            />
          </div>
        )}

        {!playing && !crashed && (
          <Button
            onClick={handleStart}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
          >
            <Play className="w-4 h-4 mr-2" />
            Start ({betAmount} FRW)
          </Button>
        )}

        {playing && (
          <Button
            onClick={handleCashout}
            className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 animate-pulse"
          >
            <Zap className="w-4 h-4 mr-2" />
            Cash Out ({(parseFloat(betAmount) * multiplier).toFixed(0)} FRW)
          </Button>
        )}

        {crashed && (
          <Button
            onClick={() => {
              setCrashed(false);
              setResult(null);
              setMultiplier(1.00);
            }}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
          >
            Play Again
          </Button>
        )}

        {result && (
          <div className={`p-4 rounded-lg border-2 text-center ${
            !result.crashed 
              ? 'bg-green-500/20 border-green-500' 
              : 'bg-red-500/20 border-red-500'
          }`}>
            {!result.crashed ? (
              <>
                <p className="text-green-400 text-2xl">Won!</p>
                <p className="text-xl">{result.winAmount.toFixed(0)} FRW</p>
                <p className="text-sm text-gray-400">at {result.multiplier.toFixed(2)}x</p>
              </>
            ) : (
              <>
                <p className="text-red-400 text-2xl">Crashed!</p>
                <p className="text-xl">at {result.crashPoint.toFixed(2)}x</p>
              </>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}

// Simplified Slots, Blackjack, and Rolling Ball games
function SlotsGame({ wallet, accessToken, onUpdateBalance }: any) {
  const [betAmount, setBetAmount] = useState('100');
  const [spinning, setSpinning] = useState(false);
  const [slots, setSlots] = useState(['🍒', '🍋', '🍊']);
  const [result, setResult] = useState<any>(null);

  const symbols = ['🍒', '🍋', '🍊', '🍉', '🍇', '⭐', '💎'];

  const handleSpin = async () => {
    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      alert('Insufficient balance!');
      return;
    }

    setSpinning(true);
    setResult(null);

    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gameType: 'slots', betAmount: bet, gameData: {} })
      }
    );

    // Spin animation
    let count = 0;
    const interval = setInterval(() => {
      setSlots([
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)]
      ]);
      count++;
      if (count > 20) {
        clearInterval(interval);
        
        // Final result
        const finalSlots = [
          symbols[Math.floor(Math.random() * symbols.length)],
          symbols[Math.floor(Math.random() * symbols.length)],
          symbols[Math.floor(Math.random() * symbols.length)]
        ];
        setSlots(finalSlots);
        setSpinning(false);

        // Check win
        let winMultiplier = 0;
        if (finalSlots[0] === finalSlots[1] && finalSlots[1] === finalSlots[2]) {
          winMultiplier = finalSlots[0] === '💎' ? 10 : 5;
        } else if (finalSlots[0] === finalSlots[1] || finalSlots[1] === finalSlots[2]) {
          winMultiplier = 2;
        }

        const winAmount = bet * winMultiplier;
        
        if (winAmount > 0) {
          fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ 
                betId: 'slots_' + Date.now(), 
                winAmount, 
                gameType: 'slots',
                gameData: { slots: finalSlots, multiplier: winMultiplier }
              })
            }
          );
        }

        setResult({ winAmount, winMultiplier });
        onUpdateBalance(wallet - bet + winAmount);
      }
    }, 100);
  };

  return (
    <Card className="bg-black/70 border-yellow-500 p-6">
      <h3 className="text-2xl neon-text mb-6 text-center">🎰 Slots</h3>

      <div className="max-w-md mx-auto space-y-6">
        <div className="bg-gradient-to-br from-yellow-900 to-orange-900 rounded-lg p-8">
          <div className="flex justify-center gap-4 text-6xl">
            {slots.map((symbol, i) => (
              <div key={i} className={spinning ? 'animate-bounce' : ''}>
                {symbol}
              </div>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm mb-2">Bet Amount (FRW)</label>
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            className="bg-black/50 border-yellow-500"
            disabled={spinning}
          />
        </div>

        <Button
          onClick={handleSpin}
          disabled={spinning}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
        >
          {spinning ? 'Spinning...' : `Spin (${betAmount} FRW)`}
        </Button>

        {result && (
          <div className={`p-4 rounded-lg border-2 text-center ${
            result.winAmount > 0 
              ? 'bg-green-500/20 border-green-500' 
              : 'bg-red-500/20 border-red-500'
          }`}>
            {result.winAmount > 0 ? (
              <>
                <p className="text-green-400 text-2xl">Won!</p>
                <p className="text-xl">{result.winAmount.toFixed(0)} FRW</p>
                <p className="text-sm text-gray-400">{result.winMultiplier}x multiplier</p>
              </>
            ) : (
              <p className="text-red-400">Try again!</p>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}

function BlackjackGame({ wallet, accessToken, onUpdateBalance }: any) {
  return (
    <Card className="bg-black/70 border-red-500 p-6">
      <h3 className="text-2xl neon-text mb-6 text-center">🃏 Blackjack</h3>
      <div className="text-center py-12">
        <p className="text-gray-400 mb-4">Classic blackjack game</p>
        <Badge className="bg-yellow-500/20 border-yellow-500">Coming Soon</Badge>
      </div>
    </Card>
  );
}

function RollingBallGame({ wallet, accessToken, onUpdateBalance }: any) {
  const [betAmount, setBetAmount] = useState('100');
  const [playing, setPlaying] = useState(false);
  const [ballPosition, setBallPosition] = useState(50);
  const [ballHeight, setBallHeight] = useState(0);
  const [targetZone, setTargetZone] = useState({ start: 40, end: 60 });
  const [speed, setSpeed] = useState(0);
  const [gravity, setGravity] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [multiplier, setMultiplier] = useState(2.0);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    if (!playing) return;

    const interval = setInterval(() => {
      // Physics simulation
      setBallPosition(prev => {
        const newPos = prev + speed;
        
        // Check if ball stopped
        if (Math.abs(speed) < 0.1 && Math.abs(gravity) < 0.1) {
          setTimeout(() => {
            setPlaying(false);
            setGameOver(true);
            
            // Check if in target zone
            const inZone = newPos >= targetZone.start && newPos <= targetZone.end;
            setWon(inZone);
            
            if (inZone) {
              handleWin();
            } else {
              handleLoss();
            }
          }, 500);
          
          return newPos;
        }
        
        // Bounce off edges with realistic physics
        if (newPos <= 0 || newPos >= 100) {
          setSpeed(s => -s * 0.7);
          setGravity(g => g * 0.8); // Energy loss
          return Math.max(0, Math.min(100, newPos));
        }
        
        return newPos;
      });

      // Simulate bounce height
      setBallHeight(prev => {
        const newHeight = prev + gravity;
        if (newHeight <= 0 && gravity < 0) {
          setGravity(g => -g * 0.6); // Bounce with energy loss
          return 0;
        }
        return Math.max(0, newHeight);
      });

      // Update gravity
      setGravity(g => g - 0.5); // Gravity pulls down
      
      // Apply friction
      setSpeed(s => s * 0.98);

      // Rotation based on speed
      setRotation(r => r + speed * 5);
    }, 50);

    return () => clearInterval(interval);
  }, [playing, speed, gravity, targetZone]);

  const handleStart = async () => {
    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      alert('Insufficient balance!');
      return;
    }

    // Random target zone
    const zoneSize = 20;
    const start = Math.random() * (100 - zoneSize);
    setTargetZone({ start, end: start + zoneSize });
    
    // Random starting position and speed with initial height
    setBallPosition(50);
    setBallHeight(30); // Start with bounce
    setSpeed((Math.random() - 0.5) * 4);
    setGravity(5); // Initial upward velocity
    setRotation(0);
    setMultiplier(2.0 + Math.random() * 2);
    
    setPlaying(true);
    setGameOver(false);

    // Place bet
    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gameType: 'rolling', betAmount: bet, gameData: {} })
      }
    );
  };

  const handleWin = async () => {
    const winAmount = parseFloat(betAmount) * multiplier;
    
    await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          betId: 'rolling_' + Date.now(), 
          winAmount, 
          gameType: 'rolling',
          gameData: { multiplier }
        })
      }
    );

    onUpdateBalance(wallet - parseFloat(betAmount) + winAmount);
  };

  const handleLoss = () => {
    onUpdateBalance(wallet - parseFloat(betAmount));
  };

  return (
    <Card className="bg-black/70 border-green-500 p-6">
      <h3 className="text-2xl neon-text mb-6 text-center">⚽ Rolling Ball</h3>

      <div className="max-w-2xl mx-auto space-y-6">
        {!playing && !gameOver && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">Bet Amount (FRW)</label>
              <Input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                min="10"
                className="bg-black/50 border-green-500"
              />
            </div>

            <Button
              onClick={handleStart}
              className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600"
            >
              Roll Ball ({betAmount} FRW)
            </Button>

            <div className="bg-green-500/10 border border-green-500 rounded-lg p-3">
              <p className="text-sm text-green-400">
                🎯 Land the ball in the green zone to win up to 4x your bet!
              </p>
            </div>
          </div>
        )}

        {(playing || gameOver) && (
          <>
            {/* 3D Realistic Rolling Track */}
            <div className="relative h-64 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-2xl border-4 border-green-500/50 overflow-hidden shadow-2xl" style={{ perspective: '1000px' }}>
              {/* 3D Background layers for depth */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-gray-700/20 to-transparent" style={{ transform: 'rotateX(10deg)' }}></div>
              
              {/* Track surface with lighting */}
              <div className="absolute inset-0">
                {/* Lighting gradient */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"></div>
                
                {/* Grid lines for depth perception */}
                {[0, 20, 40, 60, 80, 100].map(pos => (
                  <div
                    key={pos}
                    className="absolute top-0 h-full w-px bg-white/5"
                    style={{ left: `${pos}%` }}
                  />
                ))}
                
                {/* Horizontal lines for perspective */}
                {[0, 33, 66, 100].map(pos => (
                  <div
                    key={pos}
                    className="absolute left-0 w-full h-px bg-white/5"
                    style={{ top: `${pos}%` }}
                  />
                ))}
              </div>

              {/* Target zone with 3D effect */}
              <motion.div
                className="absolute bottom-0 h-20 bg-gradient-to-t from-green-500/40 via-green-500/20 to-transparent border-x-4 border-green-500"
                style={{
                  left: `${targetZone.start}%`,
                  width: `${targetZone.end - targetZone.start}%`,
                  boxShadow: '0 -10px 50px rgba(34, 197, 94, 0.4)'
                }}
                animate={{
                  boxShadow: playing ? [
                    '0 -10px 50px rgba(34, 197, 94, 0.4)',
                    '0 -10px 70px rgba(34, 197, 94, 0.6)',
                    '0 -10px 50px rgba(34, 197, 94, 0.4)'
                  ] : '0 -10px 50px rgba(34, 197, 94, 0.4)'
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="flex items-center justify-center h-full">
                  <motion.span 
                    className="text-4xl font-black text-green-400"
                    animate={{
                      scale: [1, 1.2, 1]
                    }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    {multiplier.toFixed(1)}x
                  </motion.span>
                </div>
              </motion.div>

              {/* Ball with realistic 3D physics */}
              <motion.div
                className="absolute"
                style={{
                  left: `${ballPosition}%`,
                  bottom: `${20 + ballHeight}px`,
                  transform: 'translateX(-50%)',
                }}
              >
                {/* Ball shadow */}
                <motion.div
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-16 h-4 bg-black/60 rounded-full blur-md"
                  animate={{
                    scale: ballHeight > 0 ? [1, 1.5, 1] : 1,
                    opacity: ballHeight > 0 ? 0.3 : 0.6
                  }}
                />
                
                {/* Ball with 3D effect */}
                <motion.div
                  className="relative w-16 h-16"
                  style={{
                    transform: `rotate(${rotation}deg)`
                  }}
                >
                  {/* Ball outer glow */}
                  <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-orange-600 rounded-full blur-lg opacity-60"></div>
                  
                  {/* Ball main body */}
                  <div 
                    className="relative w-16 h-16 rounded-full flex items-center justify-center"
                    style={{
                      background: 'radial-gradient(circle at 30% 30%, #fef08a, #fbbf24, #f59e0b, #d97706)',
                      boxShadow: '0 10px 30px rgba(251, 191, 36, 0.6), inset -5px -5px 15px rgba(0, 0, 0, 0.4), inset 5px 5px 15px rgba(255, 255, 255, 0.3)'
                    }}
                  >
                    {/* Highlight */}
                    <div 
                      className="absolute top-2 left-3 w-6 h-6 bg-white/60 rounded-full blur-sm"
                      style={{ filter: 'blur(4px)' }}
                    />
                    
                    {/* Ball icon */}
                    <span className="text-3xl relative z-10">⚽</span>
                  </div>

                  {/* Motion blur effect when moving fast */}
                  {playing && Math.abs(speed) > 1 && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-yellow-400/40 to-transparent rounded-full"
                      style={{
                        filter: 'blur(8px)',
                        transform: speed > 0 ? 'scaleX(-1)' : 'scaleX(1)'
                      }}
                    />
                  )}
                </motion.div>
              </motion.div>

              {/* Floating particles */}
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-yellow-400 rounded-full"
                    style={{
                      left: `${Math.random() * 100}%`,
                      bottom: '10%'
                    }}
                    animate={{
                      y: [-20, -60, -20],
                      x: [(Math.random() - 0.5) * 20, 0, (Math.random() - 0.5) * 20],
                      opacity: [0, 1, 0],
                      scale: [0, 1.5, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.2,
                      ease: "easeInOut"
                    }}
                  />
                ))}
              </div>
            </div>

            {playing && (
              <motion.p 
                className="text-center text-gray-400 flex items-center justify-center gap-2"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <span className="text-2xl">🎲</span>
                <span>Ball is rolling with physics...</span>
              </motion.p>
            )}
          </>
        )}

        {gameOver && (
          <div className={`p-6 rounded-lg border-2 text-center ${
            won ? 'bg-green-500/20 border-green-500' : 'bg-red-500/20 border-red-500'
          }`}>
            <p className={`text-3xl mb-4 ${won ? 'text-green-400' : 'text-red-400'}`}>
              {won ? '🎉 Perfect Shot!' : '❌ Missed!'}
            </p>
            {won && (
              <>
                <p className="text-2xl mb-2">{multiplier.toFixed(1)}x</p>
                <p className="text-xl">Won: {(parseFloat(betAmount) * multiplier).toFixed(0)} FRW</p>
              </>
            )}
            {!won && (
              <p className="text-xl">Lost: {betAmount} FRW</p>
            )}
            <Button
              onClick={() => {
                setGameOver(false);
                setBallPosition(50);
              }}
              className="mt-4 bg-gradient-to-r from-green-500 to-teal-500"
            >
              Play Again
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
