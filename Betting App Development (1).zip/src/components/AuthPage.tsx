import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { AnimatedLogo } from './AnimatedLogo';

interface AuthPageProps {
  onSignup: (data: any) => void;
  onLogin: (data: any) => void;
}

export function AuthPage({ onSignup, onLogin }: AuthPageProps) {
  const [authType, setAuthType] = useState<'signup' | 'login'>('signup');
  const [signupMethod, setSignupMethod] = useState<'email' | 'phone'>('phone');
  
  // Signup states
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+250');
  const [password, setPassword] = useState('');
  
  // Login states
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const handleSignup = () => {
    if (signupMethod === 'email') {
      onSignup({ email, password, type: 'email' });
    } else {
      onSignup({ phone: countryCode + phone, countryCode, password, type: 'phone' });
    }
  };

  const handleLogin = () => {
    // Check if it's email or phone
    const isEmail = loginIdentifier.includes('@');
    if (isEmail) {
      onLogin({ email: loginIdentifier, password: loginPassword });
    } else {
      onLogin({ phone: loginIdentifier, password: loginPassword });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0a0015] p-4">
      {/* Background animated elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-72 h-72 bg-pink-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 neon-border bg-black/90 backdrop-blur-xl p-8">
        {/* Animated Logo */}
        <div className="text-center mb-8">
          <AnimatedLogo size="large" />
          <p className="text-cyan-400 mt-4">Premium Betting Experience</p>
          <div className="mt-2 inline-block px-3 py-1 bg-yellow-500/20 border border-yellow-500 rounded-full">
            <span className="text-yellow-400">+10 Years Only</span>
          </div>
        </div>

        <Tabs value={authType} onValueChange={(v) => setAuthType(v as 'signup' | 'login')}>
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-purple-900/30">
            <TabsTrigger value="signup" className="data-[state=active]:bg-pink-500">Sign Up</TabsTrigger>
            <TabsTrigger value="login" className="data-[state=active]:bg-cyan-500">Login</TabsTrigger>
          </TabsList>

          {/* Signup Tab */}
          <TabsContent value="signup" className="space-y-4">
            <div className="space-y-4">
              {/* Method Selection */}
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant={signupMethod === 'phone' ? 'default' : 'outline'}
                  onClick={() => setSignupMethod('phone')}
                  className={signupMethod === 'phone' ? 'bg-pink-500 hover:bg-pink-600' : ''}
                >
                  Phone
                </Button>
                <Button
                  type="button"
                  variant={signupMethod === 'email' ? 'default' : 'outline'}
                  onClick={() => setSignupMethod('email')}
                  className={signupMethod === 'email' ? 'bg-cyan-500 hover:bg-cyan-600' : ''}
                >
                  Email (Optional)
                </Button>
              </div>

              {/* Phone Signup */}
              {signupMethod === 'phone' && (
                <div className="space-y-4">
                  <div>
                    <Label>Country Code</Label>
                    <Select value={countryCode} onValueChange={setCountryCode}>
                      <SelectTrigger className="bg-black/50 border-purple-500">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="+250">🇷🇼 +250 (Rwanda)</SelectItem>
                        <SelectItem value="+256">🇺🇬 +256 (Uganda)</SelectItem>
                        <SelectItem value="+254">🇰🇪 +254 (Kenya)</SelectItem>
                        <SelectItem value="+255">🇹🇿 +255 (Tanzania)</SelectItem>
                        <SelectItem value="+257">🇧🇮 +257 (Burundi)</SelectItem>
                        <SelectItem value="+243">🇨🇩 +243 (DR Congo)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Phone Number</Label>
                    <div className="flex gap-2">
                      <div className="px-3 py-2 bg-black/50 border border-purple-500 rounded-md text-cyan-400">
                        {countryCode}
                      </div>
                      <Input
                        type="tel"
                        placeholder="7XXXXXXXX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="bg-black/50 border-purple-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Email Signup */}
              {signupMethod === 'email' && (
                <div>
                  <Label>Email Address</Label>
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-black/50 border-purple-500"
                  />
                </div>
              )}

              <div>
                <Label>Password</Label>
                <Input
                  type="password"
                  placeholder="Create password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-black/50 border-purple-500"
                />
              </div>

              <Button 
                onClick={handleSignup} 
                className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
              >
                Sign Up & Get 1000 FRW Bonus! 🎁
              </Button>

              <p className="text-xs text-center text-gray-400">
                By signing up, you agree to our terms and confirm you are 10+ years old
              </p>
            </div>
          </TabsContent>

          {/* Login Tab */}
          <TabsContent value="login" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label>Email or Phone</Label>
                <Input
                  type="text"
                  placeholder="Email or phone number"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  className="bg-black/50 border-cyan-500"
                />
              </div>

              <div>
                <Label>Password</Label>
                <Input
                  type="password"
                  placeholder="Enter password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="bg-black/50 border-cyan-500"
                />
              </div>

              <Button 
                onClick={handleLogin} 
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
              >
                Login
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Social Info */}
        <div className="mt-6 pt-6 border-t border-purple-500/30 text-center space-y-2">
          <p className="text-sm text-gray-400">Follow us for bonus!</p>
          <div className="flex justify-center gap-4">
            <span className="text-pink-400">@___bim_is_</span>
            <span className="text-cyan-400">@___bim_was_</span>
          </div>
          <p className="text-xs text-gray-500">+2000 FRW bonus for following both!</p>
        </div>
      </Card>
    </div>
  );
}
