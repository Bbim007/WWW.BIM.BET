import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Star, MessageCircle, X, Instagram, Play } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { projectId } from '../utils/supabase/info';

interface UniqueGamesProps {
  wallet: number;
  accessToken: string;
  onUpdateBalance: (newBalance: number) => void;
}

export function UniqueGames({ wallet, accessToken, onUpdateBalance }: UniqueGamesProps) {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  const games = [
    { id: 'car', name: 'Car Racing', icon: '🏎️', color: 'from-red-500 to-orange-500' },
    { id: 'airplane', name: 'Airplane', icon: '✈️', color: 'from-blue-500 to-cyan-500' },
    { id: 'horse', name: 'Horse Racing', icon: '🐎', color: 'from-yellow-500 to-amber-500' }
  ];

  return (
    <div className="space-y-6">
      {!selectedGame ? (
        <>
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Star className="w-8 h-8 text-yellow-400" />
              <h2 className="text-3xl neon-text">VIP Games</h2>
              <Star className="w-8 h-8 text-yellow-400" />
            </div>
            <p className="text-gray-400">Exclusive games for players with 10,000+ FRW</p>
            <Badge className="mt-2 bg-yellow-500/20 border-yellow-500 text-yellow-400">
              Premium Access Unlocked
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {games.map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, scale: 0.8, y: 50 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ delay: index * 0.15, type: 'spring', stiffness: 100 }}
                whileHover={{ 
                  scale: 1.08,
                  rotateY: 8,
                  rotateX: -5,
                  transition: { duration: 0.3 }
                }}
                whileTap={{ scale: 0.95 }}
                style={{ perspective: 1000 }}
              >
                <Card
                  className="cursor-pointer bg-gradient-to-br from-black/90 via-black/80 to-black/90 border-2 border-yellow-500/30 hover:border-yellow-500 transition-all p-6 relative overflow-hidden group"
                  onClick={() => setSelectedGame(game.id)}
                >
                  {/* Animated background glow */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-0 group-hover:opacity-20 transition-opacity`}
                    animate={{
                      scale: [1, 1.2, 1],
                      rotate: [0, 180, 360]
                    }}
                    transition={{
                      duration: 20,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />

                  {/* VIP Badge */}
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-yellow-500/20 border-yellow-500 text-yellow-400">
                      <Star className="w-3 h-3 mr-1" />
                      VIP
                    </Badge>
                  </div>

                  {/* Floating 3D Icon */}
                  <motion.div 
                    className="relative mb-4"
                    animate={{
                      y: [0, -15, 0],
                      rotateY: [0, 360],
                      rotateZ: [-5, 5, -5]
                    }}
                    transition={{
                      y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
                      rotateY: { duration: 8, repeat: Infinity, ease: "linear" },
                      rotateZ: { duration: 4, repeat: Infinity, ease: "easeInOut" }
                    }}
                  >
                    <div 
                      className={`text-8xl text-center bg-gradient-to-r ${game.color} bg-clip-text text-transparent relative`}
                      style={{
                        filter: 'drop-shadow(0 15px 40px rgba(251, 191, 36, 0.6))',
                        textShadow: '0 0 50px rgba(251, 191, 36, 0.9)'
                      }}
                    >
                      {game.icon}
                      
                      {/* Multiple 3D shadow layers */}
                      <div 
                        className="absolute inset-0 text-8xl text-center opacity-30 blur-sm"
                        style={{ 
                          transform: 'translateZ(-15px) translateY(8px)',
                          color: 'rgba(0, 0, 0, 0.5)'
                        }}
                      >
                        {game.icon}
                      </div>
                      <div 
                        className="absolute inset-0 text-8xl text-center opacity-20 blur-md"
                        style={{ 
                          transform: 'translateZ(-30px) translateY(15px)',
                          color: 'rgba(0, 0, 0, 0.3)'
                        }}
                      >
                        {game.icon}
                      </div>
                    </div>
                  </motion.div>

                  <h3 className="text-center text-xl mb-3 font-black tracking-wide">{game.name}</h3>
                  
                  <Button className={`w-full bg-gradient-to-r ${game.color} relative overflow-hidden shadow-lg hover:shadow-2xl transition-all`}>
                    <motion.span
                      className="absolute inset-0 bg-white/30"
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.6 }}
                    />
                    <Play className="w-4 h-4 mr-2 relative z-10" />
                    <span className="relative z-10 font-bold">Play Now</span>
                  </Button>

                  {/* Orbiting particles */}
                  <div className="absolute inset-0 pointer-events-none">
                    {[...Array(4)].map((_, i) => (
                      <motion.div
                        key={i}
                        className={`absolute w-2 h-2 bg-gradient-to-r ${game.color} rounded-full`}
                        style={{
                          left: '50%',
                          top: '50%'
                        }}
                        animate={{
                          x: [0, Math.cos(i * Math.PI / 2) * 60, 0],
                          y: [0, Math.sin(i * Math.PI / 2) * 60, 0],
                          opacity: [0, 1, 0],
                          scale: [0, 1, 0]
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          delay: i * 0.2,
                          ease: "easeInOut"
                        }}
                      />
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          <Card className="bg-yellow-500/10 border-yellow-500 p-4">
            <h4 className="text-lg mb-2 text-yellow-400">How to Play:</h4>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Place your bet to start the game</li>
              <li>• Navigate using the game controls (Arrow keys or buttons)</li>
              <li>• Dodge obstacles to survive and increase multipliers</li>
              <li>• Collect green multiplier bonuses to boost your winnings</li>
              <li>• Any collision ends the game - you lose your bet!</li>
              <li>• Cash out anytime to secure your winnings</li>
            </ul>
          </Card>
        </>
      ) : (
        <div>
          <Button
            variant="outline"
            onClick={() => setSelectedGame(null)}
            className="mb-4"
          >
            ← Back to VIP Games
          </Button>

          {selectedGame === 'car' && (
            <RacingGame 
              vehicle="car"
              icon="🏎️"
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'airplane' && (
            <RacingGame 
              vehicle="airplane"
              icon="✈️"
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
          {selectedGame === 'horse' && (
            <RacingGame 
              vehicle="horse"
              icon="🐎"
              wallet={wallet} 
              accessToken={accessToken} 
              onUpdateBalance={onUpdateBalance} 
            />
          )}
        </div>
      )}
    </div>
  );
}

function RacingGame({ vehicle, icon, wallet, accessToken, onUpdateBalance }: any) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [betAmount, setBetAmount] = useState('1000');
  const [playing, setPlaying] = useState(false);
  const [currentMultiplier, setCurrentMultiplier] = useState(1.0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [finalAmount, setFinalAmount] = useState(0);
  const [showAssistant, setShowAssistant] = useState(false);
  const [score, setScore] = useState(0);

  // Instagram bonus tracking
  const [instagramBonus, setInstagramBonus] = useState({
    bim_was: { claimed: false, visitTime: null as number | null },
    bim_is: { claimed: false, visitTime: null as number | null }
  });

  // Game state refs
  const playerXRef = useRef(200);
  const playerYRef = useRef(500);
  const obstaclesRef = useRef<any[]>([]);
  const multiplierRef = useRef(1.0);
  const scoreRef = useRef(0);
  const keysPressed = useRef<Set<string>>(new Set());
  const gameLoopRef = useRef<number | null>(null);
  const survivalTimeRef = useRef(0);

  // Check Instagram bonus eligibility
  useEffect(() => {
    const checkVisibility = () => {
      if (!document.hidden) {
        // User came back - check if eligible for bonus
        const now = Date.now();
        
        if (instagramBonus.bim_was.visitTime && !instagramBonus.bim_was.claimed) {
          const elapsed = now - instagramBonus.bim_was.visitTime;
          if (elapsed >= 60000) { // 1 minute
            const bonus = 500;
            onUpdateBalance(wallet + bonus);
            setInstagramBonus(prev => ({
              ...prev,
              bim_was: { ...prev.bim_was, claimed: true }
            }));
            toast.success(`🎉 @___bim_was_ bonus claimed! +${bonus} FRW`);
          }
        }
        
        if (instagramBonus.bim_is.visitTime && !instagramBonus.bim_is.claimed) {
          const elapsed = now - instagramBonus.bim_is.visitTime;
          if (elapsed >= 60000) { // 1 minute
            const bonus = 500;
            onUpdateBalance(wallet + bonus);
            setInstagramBonus(prev => ({
              ...prev,
              bim_is: { ...prev.bim_is, claimed: true }
            }));
            toast.success(`🎉 @___bim_is_ bonus claimed! +${bonus} FRW`);
          }
        }
      }
    };

    document.addEventListener('visibilitychange', checkVisibility);
    return () => document.removeEventListener('visibilitychange', checkVisibility);
  }, [instagramBonus, wallet, onUpdateBalance]);

  const handleInstagramClick = (account: 'bim_was' | 'bim_is') => {
    const urls = {
      bim_was: 'https://www.instagram.com/___bim_was_/',
      bim_is: 'https://www.instagram.com/___bim_is_/'
    };

    // Mark visit time
    setInstagramBonus(prev => ({
      ...prev,
      [account]: { ...prev[account], visitTime: Date.now() }
    }));

    // Open Instagram in new tab
    window.open(urls[account], '_blank');
    
    toast.info(`Follow the account and come back after 1 minute to claim your 500 FRW bonus!`);
  };

  useEffect(() => {
    if (!playing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let roadOffset = 0;
    let obstacleSpawnTimer = 0;
    let uiUpdateCounter = 0;

    const gameLoop = () => {
      survivalTimeRef.current++;
      
      // Clear canvas
      ctx.fillStyle = '#0a0015';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw animated road/track
      roadOffset = (roadOffset + 3) % 40;
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Draw road edges
      ctx.fillStyle = '#4b5563';
      ctx.fillRect(0, 0, 40, canvas.height);
      ctx.fillRect(canvas.width - 40, 0, 40, canvas.height);
      
      // Lane lines (animated)
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 3;
      ctx.setLineDash([20, 15]);
      ctx.lineDashOffset = -roadOffset;
      for (let i = 1; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(canvas.width / 3 * i, 0);
        ctx.lineTo(canvas.width / 3 * i, canvas.height);
        ctx.stroke();
      }
      ctx.setLineDash([]);

      // Handle controls
      const speed = 6;
      if (keysPressed.current.has('ArrowUp') || keysPressed.current.has('w')) {
        playerYRef.current = Math.max(50, playerYRef.current - speed);
      }
      if (keysPressed.current.has('ArrowDown') || keysPressed.current.has('s')) {
        playerYRef.current = Math.min(canvas.height - 50, playerYRef.current + speed);
      }
      if (keysPressed.current.has('ArrowLeft') || keysPressed.current.has('a')) {
        playerXRef.current = Math.max(60, playerXRef.current - speed);
      }
      if (keysPressed.current.has('ArrowRight') || keysPressed.current.has('d')) {
        playerXRef.current = Math.min(canvas.width - 60, playerXRef.current + speed);
      }

      // Draw player with glow effect
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#fbbf24';
      ctx.font = 'bold 40px Arial';
      ctx.fillText(icon, playerXRef.current - 20, playerYRef.current + 15);
      ctx.shadowBlur = 0;

      // Draw player shield/hitbox
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.3)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(playerXRef.current, playerYRef.current, 25, 0, Math.PI * 2);
      ctx.stroke();

      // Update obstacles
      obstaclesRef.current = obstaclesRef.current
        .map(obs => ({
          ...obs,
          y: obs.y + obs.speed
        }))
        .filter(obs => obs.y < canvas.height + 50);

      // Check collisions and draw obstacles
      let collisionDetected = false;
      obstaclesRef.current.forEach(obs => {
        // Draw shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.beginPath();
        ctx.ellipse(obs.x, obs.y + 35, 20, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Draw obstacle with glow
        if (obs.type === 'bonus') {
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#10b981';
        } else if (obs.type === 'danger') {
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#ef4444';
        }
        
        ctx.font = 'bold 36px Arial';
        ctx.fillText(obs.icon, obs.x - 18, obs.y + 12);
        ctx.shadowBlur = 0;

        // Draw multiplier label
        ctx.font = 'bold 16px Arial';
        ctx.fillStyle = obs.type === 'bonus' ? '#10b981' : '#ef4444';
        const label = obs.type === 'bonus' ? `+${obs.multiplier.toFixed(1)}x` : '💥';
        ctx.fillText(label, obs.x - 20, obs.y + 35);

        // Check collision
        const distance = Math.sqrt(
          Math.pow(playerXRef.current - obs.x, 2) + Math.pow(playerYRef.current - obs.y, 2)
        );

        if (distance < 35 && !obs.passed) {
          obs.passed = true;
          
          if (obs.type === 'bonus') {
            multiplierRef.current += obs.multiplier;
            scoreRef.current += 10;
            toast.success(`+${obs.multiplier.toFixed(1)}x multiplier!`, { duration: 1000 });
          } else {
            collisionDetected = true;
          }
        }
      });

      // End game on collision
      if (collisionDetected) {
        if (gameLoopRef.current) {
          cancelAnimationFrame(gameLoopRef.current);
          gameLoopRef.current = null;
        }
        handleGameOver(false);
        return;
      }

      // Spawn new obstacles
      obstacleSpawnTimer++;
      const spawnRate = Math.max(30 - Math.floor(survivalTimeRef.current / 300), 20);
      
      if (obstacleSpawnTimer > spawnRate) {
        obstacleSpawnTimer = 0;
        
        const lanes = [
          canvas.width / 6,
          canvas.width / 2,
          (canvas.width / 6) * 5
        ];

        const numObstacles = Math.random() > 0.7 ? 2 : 1;
        
        for (let i = 0; i < numObstacles; i++) {
          const availableLanes = lanes.filter(lane => 
            !obstaclesRef.current.some(obs => 
              Math.abs(obs.x - lane) < 50 && obs.y < 100
            )
          );

          if (availableLanes.length > 0) {
            const lane = availableLanes[Math.floor(Math.random() * availableLanes.length)];
            const isBonus = Math.random() > 0.7;
            
            const dangerIcons = ['🚗', '🚙', '🚕', '🚌', '🚐', '🚛', '🏍️'];
            const bonusIcons = ['💎', '⭐', '🌟', '✨'];
            
            obstaclesRef.current.push({
              x: lane,
              y: -30,
              speed: 4 + Math.random() * 3,
              multiplier: isBonus ? 0.1 + Math.random() * 0.3 : 0,
              type: isBonus ? 'bonus' : 'danger',
              icon: isBonus 
                ? bonusIcons[Math.floor(Math.random() * bonusIcons.length)]
                : dangerIcons[Math.floor(Math.random() * dangerIcons.length)],
              passed: false
            });
          }
        }
      }

      // Gradually increase multiplier
      if (survivalTimeRef.current % 60 === 0) {
        multiplierRef.current += 0.05;
      }

      // Update UI state periodically (not every frame)
      uiUpdateCounter++;
      if (uiUpdateCounter % 10 === 0) {
        setCurrentMultiplier(multiplierRef.current);
        setScore(scoreRef.current);
      }

      // Draw UI overlay
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, canvas.width, 90);
      
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 24px Arial';
      ctx.fillText(`${multiplierRef.current.toFixed(2)}x`, 15, 35);
      
      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 20px Arial';
      ctx.fillText(`Win: ${(parseFloat(betAmount) * multiplierRef.current).toFixed(0)} FRW`, 15, 65);
      
      ctx.fillStyle = '#8b5cf6';
      ctx.font = 'bold 18px Arial';
      ctx.fillText(`Score: ${scoreRef.current}`, canvas.width - 120, 35);

      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
        gameLoopRef.current = null;
      }
    };
  }, [playing, betAmount, icon]);

  const handleKeyDown = (e: KeyboardEvent) => {
    keysPressed.current.add(e.key);
  };

  const handleKeyUp = (e: KeyboardEvent) => {
    keysPressed.current.delete(e.key);
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const handleStart = async () => {
    const bet = parseFloat(betAmount);
    if (bet > wallet) {
      toast.error('Insufficient balance!');
      return;
    }

    if (bet < 1000) {
      toast.error('Minimum bet for VIP games is 1000 FRW');
      return;
    }

    // Reset game state
    playerXRef.current = 200;
    playerYRef.current = 500;
    obstaclesRef.current = [];
    multiplierRef.current = 1.0;
    scoreRef.current = 0;
    survivalTimeRef.current = 0;

    // Place bet
    try {
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/place-bet`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ gameType: `unique_${vehicle}`, betAmount: bet, gameData: {} })
        }
      );
    } catch (error) {
      console.error('Bet placement error:', error);
    }

    setPlaying(true);
    setGameOver(false);
    setWon(false);
    setCurrentMultiplier(1.0);
    setScore(0);
  };

  const handleCashOut = async () => {
    if (!playing) return;
    
    if (gameLoopRef.current) {
      cancelAnimationFrame(gameLoopRef.current);
      gameLoopRef.current = null;
    }
    
    handleGameOver(true);
  };

  const handleGameOver = async (cashOut: boolean) => {
    setPlaying(false);
    setGameOver(true);
    setWon(cashOut);

    const finalMult = multiplierRef.current;
    const finalScr = scoreRef.current;
    const finalWin = cashOut ? parseFloat(betAmount) * finalMult : 0;
    
    setFinalAmount(finalWin);
    setCurrentMultiplier(finalMult);
    setScore(finalScr);

    if (cashOut && finalWin > parseFloat(betAmount)) {
      try {
        await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/win-bet`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
              betId: `unique_${vehicle}_` + Date.now(), 
              winAmount: finalWin, 
              gameType: `unique_${vehicle}`,
              gameData: { multiplier: finalMult, score: finalScr }
            })
          }
        );
      } catch (error) {
        console.error('Win submission error:', error);
      }
    }

    onUpdateBalance(wallet - parseFloat(betAmount) + finalWin);
  };

  return (
    <div className="space-y-4">
      {/* Instagram Bonus Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500 p-4">
          <div className="flex items-center gap-3 mb-2">
            <Instagram className="w-6 h-6 text-pink-500" />
            <div>
              <h4 className="font-bold">@___bim_was_</h4>
              <p className="text-xs text-gray-400">Follow for 500 FRW bonus</p>
            </div>
          </div>
          <Button
            onClick={() => handleInstagramClick('bim_was')}
            disabled={instagramBonus.bim_was.claimed}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            {instagramBonus.bim_was.claimed ? '✓ Claimed' : 'Follow & Get Bonus'}
          </Button>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500/20 to-red-500/20 border-orange-500 p-4">
          <div className="flex items-center gap-3 mb-2">
            <Instagram className="w-6 h-6 text-orange-500" />
            <div>
              <h4 className="font-bold">@___bim_is_</h4>
              <p className="text-xs text-gray-400">Follow for 500 FRW bonus</p>
            </div>
          </div>
          <Button
            onClick={() => handleInstagramClick('bim_is')}
            disabled={instagramBonus.bim_is.claimed}
            className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
          >
            {instagramBonus.bim_is.claimed ? '✓ Claimed' : 'Follow & Get Bonus'}
          </Button>
        </Card>
      </div>

      {/* Game Assistant Bot */}
      <div className="relative">
        <Button
          onClick={() => setShowAssistant(!showAssistant)}
          className="fixed bottom-6 right-6 rounded-full w-14 h-14 bg-gradient-to-r from-cyan-500 to-blue-500 shadow-lg z-50"
        >
          {showAssistant ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
        </Button>

        {showAssistant && (
          <Card className="fixed bottom-24 right-6 w-80 bg-black/95 border-cyan-500 p-4 z-50 shadow-2xl">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 flex items-center justify-center">
                🤖
              </div>
              <div>
                <h4 className="font-bold text-cyan-400">Game Assistant</h4>
                <p className="text-xs text-gray-400">Here to help you win!</p>
              </div>
            </div>
            
            <div className="space-y-2 text-sm text-gray-300">
              <p className="font-bold text-cyan-400">How to Play {vehicle.toUpperCase()} Racing:</p>
              <ul className="space-y-1">
                <li>🎯 Use arrow keys or buttons to move</li>
                <li>💎 Collect green bonuses to increase multiplier</li>
                <li>🚗 Dodge red obstacles - collision ends game!</li>
                <li>⏱️ Survive longer to earn more points</li>
                <li>💰 Cash out anytime to secure winnings</li>
              </ul>
              
              <div className="mt-3 pt-3 border-t border-cyan-500/30">
                <p className="font-bold text-yellow-400">Pro Tips:</p>
                <ul className="space-y-1 text-xs">
                  <li>✓ Stay in center lane for better control</li>
                  <li>✓ Watch obstacle patterns carefully</li>
                  <li>✓ Don&apos;t get greedy - cash out strategically</li>
                  <li>✓ Multiplier grows over time!</li>
                </ul>
              </div>
            </div>
          </Card>
        )}
      </div>

      <Card className="bg-black/70 border-yellow-500 p-6">
        <h3 className="text-2xl neon-text mb-6 text-center">{icon} {vehicle.charAt(0).toUpperCase() + vehicle.slice(1)} Racing</h3>

        <div className="max-w-3xl mx-auto space-y-4">
          {!playing && !gameOver && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-2">Bet Amount (FRW) - Minimum 1000</label>
                <Input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  min="1000"
                  className="bg-black/50 border-yellow-500"
                />
              </div>

              <Button
                onClick={handleStart}
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
              >
                Start Race ({betAmount} FRW)
              </Button>

              <div className="bg-blue-500/10 border border-blue-500 rounded-lg p-3">
                <p className="text-sm text-blue-400">
                  💡 Tip: Click the assistant bot (bottom right) for game instructions and winning strategies!
                </p>
              </div>
            </div>
          )}

          {playing && (
            <>
              <canvas
                ref={canvasRef}
                width={400}
                height={600}
                className="w-full border-2 border-yellow-500 rounded-lg bg-black shadow-2xl"
              />

              <div className="grid grid-cols-4 gap-2">
                <div className="col-span-4 flex justify-center">
                  <Button
                    onMouseDown={() => keysPressed.current.add('ArrowUp')}
                    onMouseUp={() => keysPressed.current.delete('ArrowUp')}
                    onTouchStart={() => keysPressed.current.add('ArrowUp')}
                    onTouchEnd={() => keysPressed.current.delete('ArrowUp')}
                    className="w-16 h-16 bg-gradient-to-b from-gray-600 to-gray-800"
                  >
                    <ArrowUp />
                  </Button>
                </div>
                <div className="col-span-4 flex justify-center gap-2">
                  <Button
                    onMouseDown={() => keysPressed.current.add('ArrowLeft')}
                    onMouseUp={() => keysPressed.current.delete('ArrowLeft')}
                    onTouchStart={() => keysPressed.current.add('ArrowLeft')}
                    onTouchEnd={() => keysPressed.current.delete('ArrowLeft')}
                    className="w-16 h-16 bg-gradient-to-b from-gray-600 to-gray-800"
                  >
                    <ArrowLeft />
                  </Button>
                  <Button
                    onMouseDown={() => keysPressed.current.add('ArrowDown')}
                    onMouseUp={() => keysPressed.current.delete('ArrowDown')}
                    onTouchStart={() => keysPressed.current.add('ArrowDown')}
                    onTouchEnd={() => keysPressed.current.delete('ArrowDown')}
                    className="w-16 h-16 bg-gradient-to-b from-gray-600 to-gray-800"
                  >
                    <ArrowDown />
                  </Button>
                  <Button
                    onMouseDown={() => keysPressed.current.add('ArrowRight')}
                    onMouseUp={() => keysPressed.current.delete('ArrowRight')}
                    onTouchStart={() => keysPressed.current.add('ArrowRight')}
                    onTouchEnd={() => keysPressed.current.delete('ArrowRight')}
                    className="w-16 h-16 bg-gradient-to-b from-gray-600 to-gray-800"
                  >
                    <ArrowRight />
                  </Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleCashOut}
                  className="flex-1 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 animate-pulse"
                >
                  💰 Cash Out ({(parseFloat(betAmount) * currentMultiplier).toFixed(0)} FRW)
                </Button>
              </div>

              <p className="text-center text-sm text-gray-400">
                Use arrow keys (WASD) or on-screen buttons to move
              </p>
            </>
          )}

          {gameOver && (
            <div className={`p-6 rounded-lg border-2 text-center ${
              won ? 'bg-green-500/20 border-green-500' : 'bg-red-500/20 border-red-500'
            }`}>
              <p className={`text-3xl mb-4 ${won ? 'text-green-400' : 'text-red-400'}`}>
                {won ? '🎉 Cashed Out!' : '💥 Collision!'}
              </p>
              <p className="text-2xl mb-2">{currentMultiplier.toFixed(2)}x Multiplier</p>
              <p className="text-xl mb-2">Score: {score} points</p>
              <p className="text-xl mb-4">{finalAmount.toFixed(0)} FRW</p>
              <Button
                onClick={() => {
                  setGameOver(false);
                  setCurrentMultiplier(1.0);
                  setScore(0);
                }}
                className="mt-4 bg-gradient-to-r from-yellow-500 to-orange-500"
              >
                Play Again
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
