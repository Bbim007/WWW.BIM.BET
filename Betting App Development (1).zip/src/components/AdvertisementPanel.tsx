import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { motion, AnimatePresence } from 'motion/react';
import { Minimize2, Maximize2, X, ThumbsUp, ThumbsDown, Play } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface AdvertisementPanelProps {
  accessToken: string;
  onUpdateBalance: (newBalance: number) => void;
}

export function AdvertisementPanel({ accessToken, onUpdateBalance }: AdvertisementPanelProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [showVideo, setShowVideo] = useState(false);

  const handleLike = async () => {
    if (liked || disliked) return;

    setLiked(true);

    // Award 50 FRW bonus
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7fe758c/video-like`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      if (data.success) {
        onUpdateBalance(data.newBalance);
      }
    } catch (error) {
      console.error('Video like error:', error);
    }
  };

  const handleDislike = () => {
    if (liked || disliked) return;
    setDisliked(true);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-4 left-4 z-40"
      >
        <Card className={`bg-black/95 border-2 border-pink-500 neon-glow overflow-hidden transition-all ${
          isMinimized ? 'w-16 h-16' : 'w-80 md:w-96'
        }`}>
          {/* Header Controls */}
          <div className="flex items-center justify-between p-2 bg-gradient-to-r from-pink-500/20 to-purple-500/20 border-b border-pink-500/30">
            <div className="flex items-center gap-2">
              {!isMinimized && (
                <span className="text-sm neon-text">BIMBETT</span>
              )}
            </div>
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="w-6 h-6 p-0"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? (
                  <Maximize2 className="w-3 h-3" />
                ) : (
                  <Minimize2 className="w-3 h-3" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="w-6 h-6 p-0"
                onClick={() => setIsOpen(false)}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          </div>

          {/* Content */}
          {!isMinimized && (
            <div className="p-4">
              {!showVideo ? (
                <div className="text-center space-y-4">
                  {/* Netflix-style intro preview */}
                  <div className="relative bg-gradient-to-br from-pink-900 via-purple-900 to-cyan-900 rounded-lg p-8 aspect-video flex items-center justify-center">
                    <div className="text-center space-y-4">
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.5 }}
                      >
                        <h1 className="text-4xl neon-text tracking-wider">BIMBETT</h1>
                      </motion.div>
                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.5 }}
                        className="text-sm text-cyan-400"
                      >
                        Premium Betting Experience
                      </motion.p>
                    </div>
                  </div>

                  <Button
                    onClick={() => setShowVideo(true)}
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Watch Full Ad
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Video Content */}
                  <div className="relative bg-black rounded-lg aspect-video flex items-center justify-center border-2 border-purple-500">
                    <div className="text-center space-y-4 p-6">
                      <motion.div
                        animate={{ 
                          scale: [1, 1.2, 1],
                          rotate: [0, 360, 0]
                        }}
                        transition={{ 
                          duration: 3,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                        className="text-6xl"
                      >
                        🎰
                      </motion.div>
                      
                      <h2 className="text-2xl neon-text">Welcome to BIMBETT!</h2>
                      <p className="text-sm text-gray-400">
                        Sign up now and get <span className="text-green-400">1000 FRW</span> bonus!
                      </p>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="p-2 bg-pink-500/20 rounded border border-pink-500">
                          <p className="text-pink-400">🎡 Casino Games</p>
                        </div>
                        <div className="p-2 bg-cyan-500/20 rounded border border-cyan-500">
                          <p className="text-cyan-400">🏆 Sports Betting</p>
                        </div>
                        <div className="p-2 bg-yellow-500/20 rounded border border-yellow-500">
                          <p className="text-yellow-400">⭐ VIP Games</p>
                        </div>
                        <div className="p-2 bg-green-500/20 rounded border border-green-500">
                          <p className="text-green-400">💰 Easy Deposits</p>
                        </div>
                      </div>

                      <p className="text-xs text-gray-500">
                        MTN & AIRTEL Mobile Money Supported
                      </p>
                    </div>
                  </div>

                  {/* Like/Dislike */}
                  <div className="flex items-center justify-between p-3 bg-purple-500/10 border border-purple-500 rounded-lg">
                    <span className="text-sm">Enjoying BIMBETT?</span>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleLike}
                        disabled={liked || disliked}
                        className={liked ? 'text-green-400' : ''}
                      >
                        <ThumbsUp className="w-4 h-4" />
                        {liked && <span className="ml-1 text-xs">+50 FRW</span>}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleDislike}
                        disabled={liked || disliked}
                        className={disliked ? 'text-red-400' : ''}
                      >
                        <ThumbsDown className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {liked && (
                    <motion.div
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-3 bg-green-500/20 border border-green-500 rounded-lg text-center"
                    >
                      <p className="text-green-400">🎉 Thank you! 50 FRW added to your wallet!</p>
                    </motion.div>
                  )}

                  <div className="text-center space-y-2">
                    <p className="text-xs text-gray-400">Follow us on Instagram for more bonuses!</p>
                    <div className="flex justify-center gap-2 text-xs">
                      <span className="text-pink-400">@___bim_is_</span>
                      <span className="text-cyan-400">@___bim_was_</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}
